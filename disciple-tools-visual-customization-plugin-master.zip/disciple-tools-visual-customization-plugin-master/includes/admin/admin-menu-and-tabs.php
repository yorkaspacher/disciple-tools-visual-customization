<?php

/**
 * DT_Visual_Customization_Plugin_Menu class for the admin page
 *
 * @class       DT_Visual_Customization_Plugin_Menu
 * @version     0.1.0
 * @since       0.1.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Initialize menu class
 */
DT_Visual_Customization_Plugin_Menu::instance();

/**
 * Class DT_Visual_Customization_Plugin_Menu
 */
class DT_Visual_Customization_Plugin_Menu
{

    public $token = 'dt_visual_customization_plugin';

    private static $_instance = null;

    /**
     * DT_Visual_Customization_Plugin_Menu Instance
     *
     * Ensures only one instance of DT_Visual_Customization_Plugin_Menu is loaded or can be loaded.
     *
     * @since 0.1.0
     * @static
     * @return DT_Visual_Customization_Plugin_Menu instance
     */
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    } // End instance()


    /**
     * Constructor function.
     * @access  public
     * @since   0.1.0
     */
    public function __construct()
    {

        add_action("admin_menu", array($this, "register_menu"));
    } // End __construct()


    /**
     * Loads the subnav page
     * @since 0.1
     */
    public function register_menu()
    {
        add_menu_page(__('Extensions (DT)', 'disciple_tools'), __('Extensions (DT)', 'disciple_tools'), 'manage_dt', 'dt_extensions', [$this, 'extensions_menu'], 'dashicons-admin-generic', 59);
        add_submenu_page('dt_extensions', __('Visual Customization', 'dt_visual_customization_plugin'), __('Visual Customization', 'dt_visual_customization_plugin'), 'manage_dt', $this->token, [$this, 'content']);
    }

    /**
     * Menu stub. Replaced when Disciple Tools Theme fully loads.
     */
    public function extensions_menu()
    {
    }

    /**
     * Builds page contents
     * @since 0.1
     */
    public function content()
    {

        if (!current_user_can('manage_dt')) { // manage dt is a permission that is specific to Disciple Tools and allows admins, strategists and dispatchers into the wp-admin
            wp_die(esc_attr__('You do not have sufficient permissions to access this page.'));
        }

        //INITIAL VARIABLES
        $wpUploadDir = wp_upload_dir();
        $progressCircleOption = [];
        $imageProgressOptionUpload = null;
        global $wpdb;
        // $results = $wpdb->get_results( "SELECT meta_value FROM wp_postmeta WHERE post_id = 100 AND meta_key = 'health_metrics'", OBJECT );

        if (isset($_FILES['imageProgressOption'])) {
            $file = $_FILES['imageProgressOption'];

            if($file["error"] == 0) {
                $upload_overrides = array('test_form' => false);

                $uploadFileResponse = wp_handle_upload($file, $upload_overrides);
                if ($uploadFileResponse && !isset($uploadFileResponse['error'])) {

                    $progressCircleOption["image"] = $wpUploadDir["subdir"] . "/" . $file["name"];

                } else {
                    $error = $uploadFileResponse['error'];
                    echo '
                    <div style="font-size: 20px; background: #ffffff; border: solid 2px #0088ff; padding: 14px 10px; text-align: center;">
                        <label style="color: #0088ff;">To upload SVG images you must install the "SVG Support" plugin</label>
                    </div>
                    ';
                }
            }
        }

        if (isset($_FILES['imageDivisionBaptized'])) {
            $file = $_FILES['imageDivisionBaptized'];

            if($file["error"] == 0) {
                $upload_overrides = array('test_form' => false);

                $uploadFileResponse = wp_handle_upload($file, $upload_overrides);
                if ($uploadFileResponse && !isset($uploadFileResponse['error'])) {

                    $imageProgressOptionUpload = $wpUploadDir["subdir"] . "/" . $file["name"];

                } else {
                    $error = $uploadFileResponse['error'];
                    echo '
                    <div style="font-size: 20px; background: #ffffff; border: solid 2px #0088ff; padding: 14px 10px; text-align: center;">
                        <label style="color: #0088ff;">To upload SVG images you must install the "SVG Support" plugin</label>
                    </div>
                    ';
                }
            }
        }

        // FORM SUBMIT -> UPDATE OPTIONS IN DATA BASE (BEFORE GET HIM IN VIEW)
        if (isset($_POST['submit'])) {

            //global $formColorTopbar, $fontStyleValue;
            $fontStyles = json_decode(get_option('vc_font_styles'), true);

            $urlFontStyleValue = "";
            $formColorTopbar = sanitize_text_field($_POST['color-topbar']);
            $fontStyleValue = sanitize_text_field($_POST['font-style']);
            $formColorPrimary = sanitize_text_field($_POST['color-primary']);
            $formColorSecondary = sanitize_text_field($_POST['color-secondary']);
            $formColorSuccess = sanitize_text_field($_POST['color-success']);
            $formColorDanger = sanitize_text_field($_POST['color-danger']);
            $formColorWarning = sanitize_text_field($_POST['color-warning']);
            $formColorInfo = sanitize_text_field($_POST['color-info']);
            $formColorSwitch = sanitize_text_field($_POST['color-switch']);
            $formColorLink = sanitize_text_field($_POST['color-link']);
            $formColorTitles = sanitize_text_field($_POST['color-titles']);
            $formColorBackground = sanitize_text_field($_POST['color-background']);
            $formColorTiles = sanitize_text_field($_POST['color-tiles']);

            foreach ($fontStyles as $key => $value) {
               if ($value["name"] == $fontStyleValue) {
                    $urlFontStyleValue = $value["url"];
               }
            }

            update_option('vc_color_topbar', $formColorTopbar);
            update_option('vc_font_style', $fontStyleValue);
            update_option('vc_url_font_style', stripslashes($urlFontStyleValue));
            update_option('vc_color_primary', $formColorPrimary);
            update_option('vc_color_secondary', $formColorSecondary);
            update_option('vc_color_success', $formColorSuccess);
            update_option('vc_color_danger', $formColorDanger);
            update_option('vc_color_warning', $formColorWarning);
            update_option('vc_color_info', $formColorInfo);
            update_option('vc_color_switch', $formColorSwitch);
            update_option('vc_color_link', $formColorLink);
            update_option('vc_color_titles', $formColorTitles);
            update_option('vc_color_background', $formColorBackground);
            update_option('vc_color_tiles', $formColorTiles);
        }

        if (isset($_POST['updatedOptions'])) {

            $updatedProgressCircleOptions = sanitize_text_field($_POST['updatedProgressCircleOptions']);

            update_option('vc_progress_circle_options', stripslashes($updatedProgressCircleOptions));
        }

        if (isset($_POST['updatedFontsForm'])) {

            $updatedFonts = sanitize_text_field($_POST['updatedFonts']);

            update_option('vc_font_styles', stripslashes($updatedFonts));
        }

        if (isset($_POST['submitOption'])) {

            $progressCircleOptions = json_decode(get_option('vc_progress_circle_options'), true);

            $name = sanitize_text_field($_POST['nameProgressOption']);
            $label = sanitize_text_field($_POST['labelProgressOption2']);
            $order = sanitize_text_field($_POST['orderProgressOption']);
            $description = sanitize_text_field($_POST['descriptionProgressOption']);
            $progressCircleImageUpload = sanitize_text_field($_POST['progressCircleImageUpload']);

            $progressCircleOption["order"] = $order;
            $progressCircleOption["label"] = $label;
            $progressCircleOption["description"] = $description;

            if(!$progressCircleOption["image"]) {
                if($progressCircleImageUpload){
                    $progressCircleOption["image"] = $progressCircleImageUpload;
                }
            }

            $progressCircleOptions["default"][$name] = $progressCircleOption;

            update_option('vc_progress_circle_options', json_encode($progressCircleOptions));
        }

        if (isset($_POST['submitBackground'])) {

            $progressCircleOptions = json_decode(get_option('vc_progress_circle_options'), true);
            $background = sanitize_text_field($_POST['backgroundProgressOption']);
            $border = sanitize_text_field($_POST['borderProgressOption']);
            $label = sanitize_text_field($_POST['labelProgressOption']);
            $progressCircleOptions["background"] = $background ? $background : $progressCircleOptions["background"];
            $progressCircleOptions["border"] = $border ? $border : $progressCircleOptions["border"];
            $progressCircleOptions["label"] = $label ? $label : $progressCircleOptions["l label"];

            update_option('vc_progress_circle_options', json_encode($progressCircleOptions));
        }

        if (isset($_POST['submitDivisionBaptizedImage'])) {

            $progressCircleOptions = json_decode(get_option('vc_progress_circle_options'), true);
            $imageDivisionBaptizedUpload = sanitize_text_field($_POST['imageDivisionBaptizedUpload']);

            $progressCircleOptions["divisionBaptizedImage"] = $imageProgressOptionUpload ? $imageProgressOptionUpload : $imageDivisionBaptizedUpload;

            update_option('vc_progress_circle_options', json_encode($progressCircleOptions));
        }

        if (isset($_POST['submitAddFont'])) {

            $fontStyles = json_decode(get_option('vc_font_styles'), true);
            $stringName = str_replace("'","",$_POST['nameNewFont']);
            $stringName = str_replace(";","",$stringName);
            $stringName = str_replace("\\","",$stringName);
            $arrayString = explode("font-family:",$stringName);
            $nameNewFont = sanitize_text_field($arrayString[1]);
            $urlNewFont = sanitize_text_field($_POST['urlNewFont']);

            array_push($fontStyles, ["name" => $nameNewFont, "url" => $urlNewFont, "default" => false]);

            update_option('vc_font_styles', json_encode($fontStyles));
        }

        if (isset($_POST['submitTitle'])) {

            $progressCircleOptions = json_decode(get_option('vc_progress_circle_options'), true);
            $title = sanitize_text_field($_POST['titleProgressOption']);
            $progressCircleOptions["name"] = $title ? $title : $progressCircleOptions["name"];

            update_option('vc_progress_circle_options', json_encode($progressCircleOptions));
        }

        if (isset($_FILES['logo'])) {
            $file = $_FILES['logo'];
            if($file["error"] == 0) {
                $upload_overrides = array('test_form' => false);
                $uploadFileResponse = wp_handle_upload($file, $upload_overrides);
                if ($uploadFileResponse && !isset($uploadFileResponse['error'])) {
                    update_option('vc_logo', $wpUploadDir["subdir"] . "/" . $file["name"]);
                } else {
                    $error = $uploadFileResponse['error'];
                    echo '
                    <div style="font-size: 20px; background: #ffffff; border: solid 2px #0088ff; padding: 14px 10px; text-align: center;">
                        <label style="color: #0088ff;">To upload SVG images you must install the "SVG Support" plugin</label>
                    </div>
                    ';
                }
            }
        }

        if (isset($_FILES['logo_login'])) {
            $file = $_FILES['logo_login'];
            if($file["error"] == 0) {
                $upload_overrides = array('test_form' => false);
                $uploadFileResponse = wp_handle_upload($file, $upload_overrides);
                if ($uploadFileResponse && !isset($uploadFileResponse['error'])) {
                    update_option('vc_logo_login', $wpUploadDir["subdir"] . "/" . $file["name"]);
                } else {
                    $error = $uploadFileResponse['error'];
                    echo '
                    <div style="font-size: 20px; background: #ffffff; border: solid 2px #0088ff; padding: 14px 10px; text-align: center;">
                        <label style="color: #0088ff;">To upload SVG images you must install the "SVG Support" plugin</label>
                    </div>
                    ';
                }
            }
        }

        // GET OPTIONS SAVED IN DATABASE

        $wpOptionVcColorTopbar = get_option('vc_color_topbar');
        $wpOptionVcFontStyle = get_option('vc_font_style');
        $wpOptionVcColorPrimary = get_option('vc_color_primary');
        $wpOptionVcColorSecondary = get_option('vc_color_secondary');
        $wpOptionVcColorSuccess = get_option('vc_color_success');
        $wpOptionVcColorDanger = get_option('vc_color_danger');
        $wpOptionVcColorWarning = get_option('vc_color_warning');
        $wpOptionVcColorInfo = get_option('vc_color_info');
        $wpOptionVcColorSwitch = get_option('vc_color_switch');
        $wpOptionVcColorLink = get_option('vc_color_link');
        $wpOptionVcColorTitles = get_option('vc_color_titles');
        $wpOptionVcColorBackground = get_option('vc_color_background');
        $wpOptionVcColorTiles = get_option('vc_color_tiles');
        $fontStyles = json_decode(get_option('vc_font_styles'), true);

        $logoPath = empty(get_option('vc_logo')) ? get_template_directory_uri() . "/dt-assets/images/disciple-tools-logo-white.png" : $wpUploadDir["baseurl"] . get_option('vc_logo');

        $logoLoginPath = empty(get_option('vc_logo_login')) ? get_template_directory_uri() . "/dt-assets/images/disciple-tools-logo-white.png" : $wpUploadDir["baseurl"] . get_option('vc_logo_login');

        $progressCircleOptions = json_decode(get_option('vc_progress_circle_options'));
        $progressCircleTemplates = json_decode(get_option('vc_progress_circle_template'));
        $progressCircleOptionsActive = json_decode(get_option('vc_progress_circle_options'));
        $progressCircleOptionsActive = $progressCircleOptionsActive->default;

        foreach ($progressCircleOptionsActive as $key => $value) {
            if($value->disable == 1 || $key == "church_commitment") {
                unset($progressCircleOptionsActive->$key);
            }
        }

        // print_r($fontStyles);

        ?>

        <div class="wrap">

        <h1>
            Visual Customization Settings
        </h1>

        <nav class="nav-tab-wrapper">
            <a href="?page=dt_visual_customization_plugin" class="nav-tab <?php if($_GET['tab']===null):?>nav-tab-active<?php endif; ?>">Theme</a>
            <a href="?page=dt_visual_customization_plugin&tab=progress-circle" class="nav-tab <?php if($_GET['tab']==='progress-circle'):?>nav-tab-active<?php endif; ?>">Progress Circle</a>
        </nav>

        <div class="tab-content">
            <?php
            switch($_GET['tab']) :
                case 'progress-circle':
            ?>


                <div class="wpbody-content">
                    <div class="wrap">

                        <h1 class="wp-heading-inline">Progress Circle</h1>
                        <button class="page-title-action" id="buttonShowForm" onclick="showForm()">Add option</button>
                        <button class="page-title-action" id="buttonHideForm" style="display:none" onclick="hideForm()">Close</button>

                        <br>
                        <br>

                        <div style="background: #ffffff; text-align: center;">
                            <canvas id="myCanvas" width="450" height="450"></canvas>
                        </div>

                        <div id="formToChangeBackground" style="display: none;">

                            <br>

                            <form action="" method="post" enctype="multipart/form-data" class="form-basic">

                                <table class="wp-list-table widefat striped users" style="padding: 10px 0;">
                                    <tbody>
                                        <tr style="background: transparent;">
                                            <td style="vertical-align: inherit;">
                                                <label style="display: block;">Background Color (*)</label>
                                                <input type="color" name="backgroundProgressOption" id="backgroundProgressOption" value="" required>
                                            </td>
                                            <td style="vertical-align: inherit;">
                                                <label style="display: block;">Border Color (*)</label>
                                                <input type="color" name="borderProgressOption" id="borderProgressOption" value="" required>
                                            </td>
                                            <td style="vertical-align: inherit;">
                                                <label style="display: block;">Label Color (*)</label>
                                                <input type="color" name="labelProgressOption" id="labelProgressOption" value="" required>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <p class="submit" style="text-align: center">
                                    <button type="submit" name="submitBackground" id="submitBackground" class="button button-primary">Submit Form</button>
                                </p>

                            </form>
                        </div>

                        <div id="showFormDivisionBaptizedImage" style="display: none;">

                            <br>

                            <form action="" method="post" enctype="multipart/form-data" class="form-basic">

                            <input type="hidden" name="imageDivisionBaptizedUpload" id="imageDivisionBaptizedUpload" >

                                <table class="wp-list-table widefat striped users" style="padding: 10px 0;">
                                    <tbody>
                                        <tr style="background: transparent;">
                                            <td style="background: #cacaca; text-align: center; vertical-align: inherit;">
                                                <img src="" id="imageDivisionBaptizedPath" style="width: 200px; height: 100px;" />
                                            </td>
                                            <td style="vertical-align: inherit;">
                                                <label style="display: block;">Image (PNG, JPG, SVG) (*)</label>
                                                <input type="file"  name="imageDivisionBaptized" id="imageDivisionBaptized" accept="image/*" require>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <p class="submit" style="text-align: center">
                                    <button type="submit" name="submitDivisionBaptizedImage" id="submitDivisionBaptizedImage" class="button button-primary">Submit Form</button>
                                </p>

                            </form>
                        </div>

                        <div id="formToChangeTitle" style="display: none;">

                            <br>

                            <form action="" method="post" enctype="multipart/form-data" class="form-basic">

                                <table class="wp-list-table widefat striped users" style="padding: 10px 0;">
                                    <tbody>
                                        <tr style="background: transparent;">
                                            <td style="vertical-align: inherit;">
                                                <label style="display: block;">Title (*)</label>
                                                <input type="text" name="titleProgressOption" id="titleProgressOption" require>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <p class="submit" style="text-align: center">
                                    <button type="submit" name="submitTitle" id="submitTitle" class="button button-primary">Submit Form</button>
                                </p>

                            </form>
                        </div>

                        <div id="formToAddOption" style="display: none;">

                            <br>
                            <br>

                            <form action="" method="post" class="form-basic">
                                <input type="hidden" name="updatedProgressCircleOptions" id="updatedProgressCircleOptions" >
                                <button type="submit" name="updatedOptions" id="updatedOptions" style="display: none;" >submit</button>
                            </form>

                            <form action="" method="post" enctype="multipart/form-data" class="form-basic">
                                <input type="hidden" name="progressCircleImageUpload" id="progressCircleImageUpload" >

                                <div id="rowWarning" style="font-size: 20px; background: #ffffff; border: solid 2px #0088ff; padding: 14px 10px; text-align: center;">
                                    <label style="color: #0088ff;">Information: The field with name = <span style="font-weight: 700;" id="fieldName"></span> is being modified</label>
                                </div>

                                <br>

                                <table class="wp-list-table widefat striped users" style="padding: 10px 0;">
                                    <tbody>
                                        <tr>
                                            <td style="vertical-align: inherit;">
                                                <label style="display: block;">Order (*)</label>
                                                <input type="text" name="orderProgressOption" id="orderProgressOption" require>
                                            </td>
                                            <td style="vertical-align: inherit;">
                                                <label style="display: block;">Key Name (*)
                                                    <span style="border: solid 1px; border-radius: 50%; padding: 0px 5px;" title="This field must be unique and without spaces">?<span>
                                                </label>
                                                <input type="text" name="nameProgressOption" id="nameProgressOption" placeholder="example_key" require>
                                            </td>
                                            <td style="vertical-align: inherit;">
                                                <label style="display: block;">Label (*)</label>
                                                <input type="text" name="labelProgressOption2" id="labelProgressOption2" require>
                                            </td>
                                            <td style="vertical-align: inherit;">
                                                <label style="display: block;">Description (*)</label>
                                                <textarea  name="descriptionProgressOption" id="descriptionProgressOption" id="" cols="30" rows="3" require></textarea>
                                            </td>
                                            <td id="rowProgressCircleImagePath" style="background: #cacaca; text-align: center; vertical-align: inherit;">
                                                <img src="" id="progressCircleImagePath" style="width: 200px; height: 100px;" />
                                            </td>
                                            <td style="vertical-align: inherit;">
                                                <label style="display: block;">Image (PNG, JPG, SVG) (*)</label>
                                                <input type="file"  name="imageProgressOption" id="imageProgressOption" accept="image/*" require>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <p class="submit" style="text-align: center">
                                    <button type="submit" name="submitOption" id="submitOption" class="button button-primary">Submit Form</button>
                                </p>

                            </form>

                        </div>

                        <br>
                        <br>

                        <h1 style="text-align: center;">Color</h1>
                        <br>
                        <table class="wp-list-table widefat striped users">
                            <thead>
                                <tr>
                                    <th width="100">Background</th>
                                    <th width="100">Border</th>
                                    <th width="100">Label</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <?php echo $progressCircleOptions->background ?> <br>
                                        <label>
                                            <a onclick="showFormBackground()">Edit</a>
                                        </label>
                                    </td>
                                    <td>
                                        <?php echo $progressCircleOptions->border ?> <br>
                                    </td>
                                    <td>
                                        <?php echo $progressCircleOptions->label ?> <br>
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                        <br>
                        <br>

                        <h1 style="text-align: center;">Section Title</h1>
                        <br>
                        <table class="wp-list-table widefat striped users">
                            <thead>
                                <tr>
                                    <th width="100">Title</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <?php echo $progressCircleOptions->name ?> <br>
                                        <label>
                                            <a onclick="showFormTitle()">Edit</a>
                                        </label>
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                        <br>
                        <br>

                        <h1 style="text-align: center;">Baptized and unbaptized division</h1>
                        <br>
                        <table class="wp-list-table widefat striped users">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th width="150">Image</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                    <?php echo $progressCircleOptions->divisionBaptizedImage ?> <br>
                                        <label>
                                            <a onclick="showFormDivisionBaptizedImage()">Edit</a>
                                        </label>
                                    </td>
                                    <td style="background: #cacaca; text-align: center;"><img src="<?php echo strpos($progressCircleOptions->divisionBaptizedImage, "dt-assets") ? get_template_directory_uri() . $progressCircleOptions->divisionBaptizedImage : $wpUploadDir["baseurl"] . $progressCircleOptions->divisionBaptizedImage ?>" style="width: 200px; height: 100px;" /></td>
                                </tr>
                            </tbody>
                        </table>

                        <br>
                        <br>

                        <h1 style="text-align: center;">Icon List</h1>
                        <br>
                        <table class="wp-list-table widefat striped users">
                            <thead>
                                <tr>
                                    <th width="50">Order</th>
                                    <th width="200">Name</th>
                                    <th width="200">Label</th>
                                    <th width="400">Description</th>
                                    <th width="100">Image</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($progressCircleOptions->default as $key => $option) : ?>
                                <tr>
                                    <td style="text-align: center;"> <?php echo $option->order ?></td>
                                    <td>
                                        <?php echo $key ?> <br>
                                        <label>
                                            <a onclick="showForm('<?php echo $key ?>')">Edit</a>
                                            <?php if ($option->disable): ?>
                                            <a onclick="enableItem('<?php echo $key ?>')">Enable</a>
                                            <?php else :?>
                                            <a onclick="disableItem('<?php echo $key ?>')">Disable</a>
                                            <?php endif;?>
                                        </label>
                                    </td>
                                    <td><?php echo $option->label ?></td>
                                    <td><?php echo $option->description ?></td>
                                    <td style="background: #cacaca; text-align: center;"><img src="<?php echo strpos($option->image, "dt-assets") ? get_template_directory_uri() . $option->image : $wpUploadDir["baseurl"] . $option->image ?>" style="width: 200px; height: 100px;" /></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>

                    </div>
                </div>

                <script type="application/javascript">

                    var options = <?php echo json_encode($progressCircleOptions); ?>;
                    var templates = <?php echo json_encode($progressCircleTemplates); ?>;
                    var progressCircleOptionsActive = <?php echo json_encode($progressCircleOptionsActive); ?>;

console.log(progressCircleOptionsActive)

                    var iconsActive = [];
                    var countCircleOptionsActive = Object.keys(progressCircleOptionsActive).length
                    var canvas = document.getElementById('myCanvas');
                    var context = canvas.getContext('2d');
                    var centerX = canvas.width / 2;
                    var centerY = canvas.height / 2;
                    var radius = 200;
                    var canvasIcons = []

                    switch(countCircleOptionsActive){

                        case 5:
                            applyTemplate(templates["iconTemplate5"])
                        break;
                        case 6:
                            applyTemplate(templates["iconTemplate6"])
                        break;
                        case 7:
                            applyTemplate(templates["iconTemplate7"])
                        break;
                        case 8:
                            applyTemplate(templates["iconTemplate8"])
                        break;
                        case 9:
                            applyTemplate(templates["iconTemplate9"])
                        break;
                        case 10:
                            applyTemplate(templates["iconTemplate10"])
                        break;
                        case 11:
                            applyTemplate(templates["iconTemplate11"])
                        break;
                        case 12:
                            applyTemplate(templates["iconTemplate12"])
                        break;

                    }

                    function applyTemplate (template) {

                        var index = 0

                        for (var key in progressCircleOptionsActive) {

                            var option = progressCircleOptionsActive[key]
                            var icon = template[index]
                            var imagePath = null

                            if(option.image){
                                if(option.image.includes("dt-assets")){
                                    imagePath = '<?php echo get_template_directory_uri(); ?>';
                                } else {
                                    imagePath = <?php echo json_encode($wpUploadDir["baseurl"]); ?>;
                                }
                            }

                            icon.id = key
                            icon.label = option.label
                            icon.imageUrl = imagePath ? imagePath + option.image : ""
                            canvasIcons.push(icon)
                            index ++
                            imagePath = null
                        }

                        index = 0
                        drawProgressCircle()
                    }

                    function drawProgressCircle () {

                        var churchCommitmentActive = false

                        iconsActive.forEach((elem, key) => {
                            if(elem.meta_value == "church_commitment"){
                                churchCommitmentActive = true
                            }
                        });

                        context.beginPath();
                        if (churchCommitmentActive) {
                            context.setLineDash([]);
                        } else {
                            context.setLineDash([10, 10]);
                        }
                        context.arc(centerX, centerY, radius, 0, 2 * Math.PI);
                        context.strokeStyle = options.border;
                        context.lineWidth = 2;
                        context.fillStyle = options.background;
                        context.globalAlpha = 1;
                        context.fill();
                        context.stroke();

                        canvasIcons.forEach((element, key) => {
                            var icon = canvas.getContext('2d');
                            var label = canvas.getContext('2d');
                            var img = new Image;
                            var iconIsActive = findIconInArray(element.id)

                            icon.id = element.id
                            img.onload = function () {

                                var imgWidth = img.width
                                var imgHeight = img.height

                                labelArray = element.label.split(' ')
                                label.globalAlpha = iconIsActive ? 1 : element.globalAlpha
                                label.fillStyle = options.label;

                                if (labelArray[0].length > 5 && labelArray.length > 1) {

                                    var labelWidth = labelArray[0].length * 4
                                    var labelTwo = labelArray[2] ? labelArray[1] + ' ' + labelArray[2] : labelArray[1]
                                    var labelTwoWidth = labelTwo.length * 4

                                    if (labelWidth > imgWidth) {

                                        var diferent = labelWidth - imgWidth

                                        label.fillText(labelArray[0], (element.x - diferent), element.y + (imgHeight + 10));
                                    } else {

                                        var diferent = (imgWidth - labelWidth)

                                        label.fillText(labelArray[0], element.x + Math.round(diferent / 3), element.y + (imgHeight + 10));
                                    }

                                    if (labelTwoWidth > imgWidth) {

                                        var diferent = labelTwoWidth - imgWidth

                                        label.fillText(labelTwo, (element.x - diferent), (element.y + 10) + (imgHeight + 10));
                                    } else {

                                        var diferent = (imgWidth - labelTwoWidth)

                                        label.fillText(labelTwo, element.x + Math.round(diferent / 3), (element.y + 10) + (imgHeight + 10));
                                    }


                                } else {

                                    var labelWidth = element.label.length * 4

                                    if (labelWidth > imgWidth) {

                                        var diferent = labelWidth - imgWidth

                                        label.fillText(element.label, (element.x - diferent), element.y + (imgHeight + 10));
                                    } else {

                                        var diferent = (imgWidth - labelWidth)

                                        label.fillText(element.label, element.x + Math.round(diferent / 3), element.y + (imgHeight + 10));
                                    }

                                }

                                icon.globalAlpha = iconIsActive ? 1 : element.globalAlpha
                                element.globalAlpha = iconIsActive ? 1 : element.globalAlpha
                                icon.drawImage(img, element.x, element.y);
                            }
                            img.src = element.imageUrl;
                        });
                    }

                    function findIconInArray (key){

                        var iconFined = false

                        iconsActive.forEach(element => {
                            if(!iconFined){
                                if(key == element.meta_value) {
                                    iconFined = true
                                }
                            }
                        });

                        return iconFined;
                    }

                    function getCursorPosition(canvas, event) {

                        const rect = canvas.getBoundingClientRect()
                        const xAxis = event.clientX - rect.left
                        const yAxis = event.clientY - rect.top
                        var contextIcon = null

                        canvasIcons.forEach(element => {

                            if (!contextIcon) {
                                if ((xAxis >= element.x && xAxis <= element.x + 40) && (yAxis >= element.y && yAxis <= element.y + 40)) {

                                    contextIcon = element

                                    context.clearRect(0, 0, canvas.width, canvas.height);

                                    canvasIcons.forEach((element, key) => {

                                        var icon = canvas.getContext('2d');
                                        var label = canvas.getContext('2d');
                                        var img = new Image;
                                        var iconIsActive = findIconInArray(element.id)

                                        icon.id = element.id

                                        if (icon.id == contextIcon.id) {
                                            if(iconIsActive && contextIcon.globalAlpha == 1){
                                                iconIsActive = false

                                                iconsActive.forEach((value, key) => {
                                                    if(contextIcon.id == value.meta_value){
                                                        iconsActive.splice(key, 1);
                                                    }
                                                });
                                            } else if(!iconIsActive && contextIcon.globalAlpha == 0.3) {
                                                iconIsActive = true
                                                iconsActive.push({meta_value: contextIcon.id})
                                            }
                                        }

                                        img.onload = function () {

                                            var imgWidth = img.width
                                            var imgHeight = img.height

                                            labelArray = element.label.split(' ')
                                            label.globalAlpha = iconIsActive ? 1 : 0.3
                                            label.fillStyle = options.label;

                                            // VALIDATION IF LABEL HAVE SPACES

                                            if (labelArray[0].length > 5 && labelArray.length > 1) {

                                                var labelWidth = labelArray[0].length * 4
                                                var labelTwo = labelArray[2] ? labelArray[1] + ' ' + labelArray[2] : labelArray[1]
                                                var labelTwoWidth = labelTwo.length * 4

                                                // LOGIC FOR LABEL ONE

                                                if (labelWidth > imgWidth) {

                                                    var diferent = labelWidth - imgWidth

                                                    label.fillText(labelArray[0], (element.x - diferent), element.y + (imgHeight + 10));
                                                } else {

                                                    var diferent = (imgWidth - labelWidth)

                                                    label.fillText(labelArray[0], element.x + Math.round(diferent / 3), element.y + (imgHeight + 10));
                                                }

                                                // LOGIC FOR LABEL TWO

                                                if (labelTwoWidth > imgWidth) {

                                                    var diferent = labelTwoWidth - imgWidth

                                                    label.fillText(labelTwo, (element.x - diferent), (element.y + 10) + (imgHeight + 10));
                                                } else {

                                                    var diferent = (imgWidth - labelTwoWidth)

                                                    label.fillText(labelTwo, element.x + Math.round(diferent / 3), (element.y + 10) + (imgHeight + 10));
                                                }


                                            } else {

                                                // LOGIC FOR LABEL

                                                var labelWidth = element.label.length * 4

                                                if (labelWidth > imgWidth) {

                                                    var diferent = labelWidth - imgWidth

                                                    label.fillText(element.label, (element.x - diferent), element.y + (imgHeight + 10));
                                                } else {

                                                    var diferent = (imgWidth - labelWidth)

                                                    label.fillText(element.label, element.x + Math.round(diferent / 3), element.y + (imgHeight + 10));
                                                }

                                            }

                                            icon.globalAlpha = iconIsActive ? 1 : 0.3
                                            element.globalAlpha = iconIsActive ? 1 : 0.3
                                            icon.drawImage(img, element.x, element.y);
                                        }
                                        img.src = element.imageUrl;
                                    });

                                    var churchCommitmentActive = false

                                    iconsActive.forEach((elem, key) => {
                                        if(elem.meta_value == "church_commitment"){
                                            churchCommitmentActive = true
                                        }
                                    });

                                    context.beginPath();
                                    if (churchCommitmentActive) {
                                        context.setLineDash([]);
                                    } else {
                                        context.setLineDash([10, 10]);
                                    }
                                    context.arc(centerX, centerY, radius, 0, 2 * Math.PI);
                                    context.strokeStyle = options.border;
                                    context.lineWidth = 2;
                                    context.fillStyle = options.background;
                                    context.globalAlpha = 1;
                                    context.fill();
                                    context.stroke();

                                }
                            } else {
                                contextIcon = null
                            }
                        });

                    }

                    canvas.addEventListener('mousedown', function(e) {
                        getCursorPosition(canvas, e)
                    })

                    function showFormBackground () {

                        var options = <?php echo json_encode($progressCircleOptions); ?>;

                        document.getElementById("backgroundProgressOption").value = options.background
                        document.getElementById("borderProgressOption").value = options.border
                        document.getElementById("labelProgressOption").value = options.label
                        document.getElementById("formToChangeBackground").style.display = 'block'
                        document.getElementById('buttonShowForm').style.display = 'none'
                        document.getElementById('buttonHideForm').style.display = 'inline-block'
                    }

                    function showFormTitle () {

                        var options = <?php echo json_encode($progressCircleOptions); ?>;

                        document.getElementById("titleProgressOption").value = options.name
                        document.getElementById("formToChangeTitle").style.display = 'block'
                        document.getElementById('buttonShowForm').style.display = 'none'
                        document.getElementById('buttonHideForm').style.display = 'inline-block'
                    }

                    function showFormDivisionBaptizedImage () {

                        var options = <?php echo json_encode($progressCircleOptions); ?>;

                        var imagePath = null

                        console.log(options)

                        if(options.divisionBaptizedImage){
                            if(options.divisionBaptizedImage.includes("dt-assets")){
                                imagePath = '<?php echo get_template_directory_uri(); ?>';
                            } else {
                                imagePath = <?php echo json_encode($wpUploadDir["baseurl"]); ?>;
                            }
                        }

                        document.getElementById("imageDivisionBaptizedUpload").value = options.divisionBaptizedImage
                        document.getElementById("imageDivisionBaptizedPath").src = imagePath ? imagePath + options.divisionBaptizedImage : ""
                        document.getElementById('showFormDivisionBaptizedImage').style.display = 'block'
                        document.getElementById('buttonShowForm').style.display = 'none'
                        document.getElementById('buttonHideForm').style.display = 'inline-block'
                    }

                    function showForm (data) {

                        var options = <?php echo json_encode($progressCircleOptions); ?>;
                        var count = Object.keys(options.default).length

                        if(data) {

                            var option = options.default[data]
                            var imagePath = null

                            if(option.image){
                                if(option.image.includes("dt-assets")){
                                    imagePath = '<?php echo get_template_directory_uri(); ?>';
                                } else {
                                    imagePath = <?php echo json_encode($wpUploadDir["baseurl"]); ?>;
                                }
                            }


                            document.getElementById("nameProgressOption").value = data
                            document.getElementById("fieldName").textContent = data
                            document.getElementById("nameProgressOption").readOnly = true;
                            document.getElementById("labelProgressOption2").value = option.label
                            document.getElementById("orderProgressOption").value = option.order
                            document.getElementById("descriptionProgressOption").value = option.description
                            document.getElementById("progressCircleImageUpload").value = option.image
                            document.getElementById("rowProgressCircleImagePath").style.display = 'block'
                            document.getElementById("rowWarning").style.display = 'block'
                            document.getElementById("progressCircleImagePath").src = imagePath ? imagePath + option.image : ""
                            document.getElementById('formToAddOption').style.display = 'block'
                            document.getElementById('buttonShowForm').style.display = 'none'
                            document.getElementById('buttonHideForm').style.display = 'inline-block'

                        } else {

                            if(count < 12){

                                document.getElementById("nameProgressOption").readOnly = false;
                                document.getElementById("nameProgressOption").value = ""
                                document.getElementById("labelProgressOption2").value = ""
                                document.getElementById("orderProgressOption").value = ""
                                document.getElementById("descriptionProgressOption").value = ""
                                document.getElementById("progressCircleImagePath").src = ""
                                document.getElementById("rowWarning").style.display = 'none'
                                document.getElementById("rowProgressCircleImagePath").style.display = 'none'
                                document.getElementById('formToAddOption').style.display = 'block'
                                document.getElementById('buttonShowForm').style.display = 'none'
                                document.getElementById('buttonHideForm').style.display = 'inline-block'
                            } else {
                                alert("You cannot have more than 12 items in the list!")
                            }
                        }
                    }

                    function disableItem (data) {

                        var options = <?php echo json_encode($progressCircleOptions); ?>;

                        options.default[data]["disable"] = 1

                        document.getElementById("updatedProgressCircleOptions").value = JSON.stringify(options)
                        document.getElementById('updatedOptions').click();

                    }

                    function enableItem (data) {

                        var options = <?php echo json_encode($progressCircleOptions); ?>;

                        options.default[data]["disable"] = 0

                        document.getElementById("updatedProgressCircleOptions").value = JSON.stringify(options)
                        document.getElementById('updatedOptions').click();

                    }

                    function hideForm (){
                        document.getElementById('formToAddOption').style.display = 'none'
                        document.getElementById('formToChangeTitle').style.display = 'none'
                        document.getElementById('formToChangeBackground').style.display = 'none'
                        document.getElementById('showFormDivisionBaptizedImage').style.display = 'none'
                        document.getElementById('buttonShowForm').style.display = 'inline-block'
                        document.getElementById('buttonHideForm').style.display = 'none'
                    }

                </script>


            <?php
                break;
                default:
            ?>


            <h1 class="wp-heading-inline">Colors</h1>
            <button class="page-title-action" id="buttonHideFormAddFont" style="display:none" onclick="hideFormAddFont()">Close</button>

            <br>
            <br>

            <div style="background: #ffffff; text-align: center; padding: 15px; text-align: left;">
                <div style="width: 700px; height: 617px; margin: auto; border: solid 1px #cdcdcd;" id="body-example">

                    <div style="width: 700px; height: 50px;" id="topbar-example">
                        <img src="<?php echo $logoPath; ?>" style="width: 69px; height: 20px; margin: 15px;" />
                    </div>

                    <div style="width: 700px; height: 50px; background: #ffffff; text-align: center">
                        <div id="sucess-color-example" style="display: inline-block; width: 90px; height: 20px; padding: 5px; color: #ffffff; text-align: center;">Create</div>
                        <div id="primary-color-example" style="margin: 10px 0; display: inline-block; width: 90px; height: 20px; padding: 5px; color: #ffffff; text-align: center;">Filter</div>
                        <div id="primary-color2-example" style="margin: 10px 0; display: inline-block; width: 90px; height: 20px; padding: 5px; color: #ffffff; text-align: center;">Duplicates</div>
                        <div style="margin: 10px 0; display: inline-block; width: 120px; height: 20px; padding: 5px; color: #ffffff; border: solid 1px #cdcdcd;">&nbsp;</div>
                        <div id="primary-color3-example" style="margin: 10px 0; display: inline-block; width: 90px; height: 20px; padding: 5px; color: #ffffff; text-align: center;">Seach</div>
                    </div>

                    <br>

                    <div>
                        <div style="border: solid 1px #cdcdcd; margin: 10px 10px; display: inline-block; width: 200px; height: 300px; padding: 5px; color: #ffffff; text-align: center; background: #ffffff; border-radius: 15px;">
                            <h3 style="text-align: left;"  id="title-example">Filters</h3>

                            <div id="topbar2-example" style="width: auto; padding: 10px 5px; background: #ffffff; text-align: left">
                                <h4 id="title8-example" style="color: white; margin: 0px;">Contacts</h4>
                            </div>
                            <div>
                                <ul style="text-align: left">
                                    <li style="color: #000000">All &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 25</li>
                                    <li style="color: #000000">Waiting to be accepted &nbsp; &nbsp; 15</li>
                                    <li style="color: #000000">Active &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 5</li>
                                    <li style="color: #000000">Paused &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 3</li>
                                    <li style="color: #000000">Closed &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 2</li>
                                </ul>
                            </div>
                        </div>

                        <div style="border: solid 1px #cdcdcd; margin: 10px 0; display: inline-block; width: 440px; height: 300px; padding: 5px; color: #ffffff; background: #ffffff; border-radius: 15px;">
                            <h3 style="text-align: left;"  id="title6-example">List</h3>
                            <div>
                                <div style="display: inline-block; width: 90px; height: 20px; padding: 5px; color: #000000; text-align: center;">Name</div>
                                <div style="display: inline-block; width: 90px; height: 20px; padding: 5px; color: #000000; text-align: center;">Status</div>
                                <div style="display: inline-block; width: 90px; height: 20px; padding: 5px; color: #000000; text-align: center;">Seeker</div>
                                <div style="display: inline-block; width: 90px; height: 20px; padding: 5px; color: #000000; text-align: center;">Location</div>
                            </div>
                            <div>
                                <div style="display: inline-block; width: 90px; height: 20px; padding: 5px; color: #000000; text-align: center;"><span id="link-example">Anderson</span> 012345</div>
                                <div style="display: inline-block; width: 90px; height: 20px; padding: 5px; color: #000000; text-align: center;">Active</div>
                                <div style="display: inline-block; width: 90px; height: 20px; padding: 5px; color: #000000; text-align: center;">Contact Established</div>
                                <div style="display: inline-block; width: 90px; height: 20px; padding: 5px; color: #000000; text-align: center;">Gibraltar</div>
                            </div>
                            <div>
                                <div style="display: inline-block; width: 90px; height: 20px; padding: 5px; color: #000000; text-align: center;"><span id="link2-example">Carlos S.</span> 548952</div>
                                <div style="display: inline-block; width: 90px; height: 20px; padding: 5px; color: #000000; text-align: center;">Paused</div>
                                <div style="display: inline-block; width: 90px; height: 20px; padding: 5px; color: #000000; text-align: center;">Contact Attempted</div>
                                <div style="display: inline-block; width: 90px; height: 20px; padding: 5px; color: #000000; text-align: center;">Morocco</div>
                            </div>
                            <div>
                                <div style="display: inline-block; width: 90px; height: 20px; padding: 5px; color: #000000; text-align: center;"><span id="link3-example">Hans R.</span> 554785</div>
                                <div style="display: inline-block; width: 90px; height: 20px; padding: 5px; color: #000000; text-align: center;">Active</div>
                                <div style="display: inline-block; width: 90px; height: 20px; padding: 5px; color: #000000; text-align: center;">Contact Established</div>
                                <div style="display: inline-block; width: 90px; height: 20px; padding: 5px; color: #000000; text-align: center;">Gibraltar</div>
                            </div>
                        </div>
                    </div>

                    <hr>

                    <div id="danger-color-example" style="text-align: center; color: #ffffff; margin: 0 14px; border-radius: 5px; padding: 10px 0px;"> <img width="10" src="<?php echo get_template_directory_uri() . '/dt-assets/images/alert-circle-exc.svg' ?>" alt=""> This contact needs an update.</div>

                    <br>

                    <div style="width: 700px; height: 30px; background: #ffffff; text-align: center">
                        <div id="secondary-color-example" style="margin:auto; width: 90px; height: 20px; padding: 5px; color: #ffffff; text-align: center;">Cancel</div>
                    </div>

                    <br>

                    <div style="width: 700px; height: 30px; background: #ffffff; text-align: center">
                        <div id="switch-color-example" style="margin:auto; width: 60px; height: 20px; padding: 5px; color: #ffffff; text-align: right;">
                            <div style=" width: 15px; height: 10px; padding: 5px; color: #ffffff; background: #ffffff; text-align: right; float: right;"></div>
                        </div>
                    </div>

                </div>
            </div>

            <div id="formToAddFont" style="display: none;">

                <br>

                <form action="" method="post" enctype="multipart/form-data" class="form-basic">

                    <table class="wp-list-table widefat striped users" style="padding: 10px 0;">
                        <tbody>
                            <tr style="background: transparent;">
                                <td style="vertical-align: inherit;">
                                    <label style="display: block;">Name (*)</label>
                                    <input type="text" name="nameNewFont" id="nameNewFont" require>
                                </td>
                                <td style="vertical-align: inherit;">
                                    <label style="display: block;">Url (*)</label>
                                    <input type="text" name="urlNewFont" id="urlNewFont" require>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <p class="submit" style="text-align: center">
                        <button type="submit" name="submitAddFont" id="submitAddFont" class="button button-primary">Submit Form</button>
                    </p>

                </form>
            </div>

            <form action="" method="post" class="form-basic">
                <input type="hidden" name="updatedFonts" id="updatedFonts" >
                <button type="submit" name="updatedFontsForm" id="updatedFontsForm" style="display: none;" >submit</button>
            </form>

            <form action="" method="post" enctype="multipart/form-data" class="form-basic">

                <table class="wp-list-table widefat striped users">
                    <tbody>
                        <tr>
                            <th width="65%" scope="row">
                                <label>Topbar Color</label>
                            </th>
                            <td>
                                <input type="color" name="color-topbar" value="<?php echo ($wpOptionVcColorTopbar) ? $wpOptionVcColorTopbar : '' ?>" required>
                            </td>
                        </tr>

                        <tr>
                            <th width="65%" scope="row">
                                <label>Primary Color</label>
                            </th>
                            <td>
                                <input type="color" name="color-primary" value="<?php echo ($wpOptionVcColorPrimary) ? $wpOptionVcColorPrimary : '' ?>" required>
                            </td>
                        </tr>

                        <tr>
                            <th width="65%" scope="row">
                                <label>Secondary Color</label>
                            </th>
                            <td>
                                <input type="color" name="color-secondary" value="<?php echo ($wpOptionVcColorSecondary) ? $wpOptionVcColorSecondary : '' ?>" required>
                            </td>
                        </tr>

                        <tr>
                            <th width="65%" scope="row">
                                <label>Success Color</label>
                            </th>
                            <td>
                                <input type="color" name="color-success" value="<?php echo ($wpOptionVcColorSuccess) ? $wpOptionVcColorSuccess : '' ?>" required>
                            </td>
                        </tr>

                        <tr>
                            <th width="65%" scope="row">
                                <label>Danger Color</label>
                            </th>
                            <td>
                                <input type="color" name="color-danger" value="<?php echo ($wpOptionVcColorDanger) ? $wpOptionVcColorDanger : '' ?>" required>
                            </td>
                        </tr>

                        <tr>
                            <th width="65%" scope="row">
                                <label>Warning Color</label>
                            </th>
                            <td>
                                <input type="color" name="color-warning" value="<?php echo ($wpOptionVcColorWarning) ? $wpOptionVcColorWarning : '' ?>" required>
                            </td>
                        </tr>

                        <tr>
                            <th width="65%" scope="row">
                                <label>Info Color</label>
                            </th>
                            <td>
                                <input type="color" name="color-info" value="<?php echo ($wpOptionVcColorInfo) ? $wpOptionVcColorInfo : '' ?>" required>
                            </td>
                        </tr>

                        <tr>
                            <th width="65%" scope="row">
                                <label>Switch Color</label>
                            </th>
                            <td>
                                <input type="color" name="color-switch" value="<?php echo ($wpOptionVcColorSwitch) ? $wpOptionVcColorSwitch : '' ?>" required>
                            </td>
                        </tr>

                        <tr>
                            <th width="65%" scope="row">
                                <label>Link Color</label>
                            </th>
                            <td>
                                <input type="color" name="color-link" value="<?php echo ($wpOptionVcColorLink) ? $wpOptionVcColorLink : '' ?>" required>
                            </td>
                        </tr>

                        <tr>
                            <th width="65%" scope="row">
                                <label>Titles Color</label>
                            </th>
                            <td>
                                <input type="color" name="color-titles" value="<?php echo ($wpOptionVcColorTitles) ? $wpOptionVcColorTitles : '' ?>" required>
                            </td>
                        </tr>

                        <tr>
                            <th width="65%" scope="row">
                                <label>Background Color</label>
                            </th>
                            <td>
                                <input type="color" name="color-background" value="<?php echo ($wpOptionVcColorBackground) ? $wpOptionVcColorBackground : '' ?>" required>
                            </td>
                        </tr>

                        <tr>
                            <th width="65%" scope="row">
                                <label>Tiles Color</label>
                            </th>
                            <td>
                                <input type="color" name="color-tiles" value="<?php echo ($wpOptionVcColorTiles) ? $wpOptionVcColorTiles : '' ?>" required>
                            </td>
                        </tr>

                    </tbody>
                </table>

                <h1 class="wp-heading-inline">Fonts</h1>

                <table class="wp-list-table widefat striped users">
                    <tbody>
                        <tr>
                            <th width="65%" scope="row">
                                <label>Font Style</label><br>
                                <label>
                                    <a onclick="showFormAddFont()">Add</a>
                                    <a onclick="deleteFont()">Delete</a>
                                </label>
                            </th>
                            <td>
                                <select id="font-style" name="font-style" required>
                                <?php foreach ($fontStyles as $fontStyle) : ?>
                                    <option style="font-family: '<?php echo $fontStyle["name"] ?>';"
                                    value="<?php echo $fontStyle["name"] ?>" <?php if ($fontStyle["name"] == $wpOptionVcFontStyle) : ?> selected="selected" <?php endif; ?>><?php echo $fontStyle["name"] ?></option>
                                <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                    </tbody>
                </table>

                <h1 class="wp-heading-inline">Images</h1>

                <h3 class="wp-heading-inline">Logo sidebar</h3>

                <table class="wp-list-table widefat striped users">
                    <tbody>
                        <tr>
                            <th width="65%" scope="row">
                                <label>Logo (PNG, JPG, SVG)</label>
                            </th>
                            <td>
                                <img src="<?php echo $logoPath; ?>" style="width: 200px; height: 100px;" />
                                <br>
                                <input type="file" name="logo">
                            </td>
                        </tr>
                    </tbody>
                </table>

                <br>

                <h3 class="wp-heading-inline">Logo login</h3>

                <table class="wp-list-table widefat striped users">
                    <tbody>
                        <tr>
                            <th width="65%" scope="row">
                                <label>Logo Login (PNG, JPG, SVG)</label>
                            </th>
                            <td>
                                <img src="<?php echo $logoLoginPath; ?>" style="width: 200px; height: 100px;" />
                                <br>
                                <input type="file" name="logo_login">
                            </td>
                        </tr>
                    </tbody>
                </table>

                <p class="submit">
                    <button type="submit" name="submit" class="button button-primary">Submit Form</button>
                </p>

            </form>

            <script type="application/javascript">

                var element = document.getElementById("font-style");
                var fontStyles = <?php echo json_encode($fontStyles); ?>;
                var option = element.options[element.selectedIndex].text;
                var fontFamily = ""

                if (option == "Calibri") {
                    fontFamily = "Calibri,Candara,Segoe,Segoe UI,Optima,Arial,sans-serif"
                } else if (option == "Arial") {
                    fontFamily = "Arial, Helvetica, sans-serif"
                } else if (option == "Comic Sans MS") {
                    fontFamily = "Comic Sans MS, Comic Sans, cursive"
                } else {
                    fontFamily = option
                }

                var css = '';

                fontStyles.forEach(element => {
                    if (element.name == option) {
                        css = element.url.replace(/\\/g, '');
                    }
                });

                head = document.head || document.getElementsByTagName('head')[0],
                style = document.createElement('style');

                head.appendChild(style);

                style.type = 'text/css';
                style.appendChild(document.createTextNode(css));


                document.getElementById("title-example").style.color = document.querySelector('input[name=color-titles]').value
                document.getElementById("title6-example").style.color = document.querySelector('input[name=color-titles]').value
                document.getElementById("link-example").style.color = document.querySelector('input[name=color-link]').value
                document.getElementById("link2-example").style.color = document.querySelector('input[name=color-link]').value
                document.getElementById("link3-example").style.color = document.querySelector('input[name=color-link]').value
                document.getElementById("topbar-example").style.background = document.querySelector('input[name=color-topbar]').value
                document.getElementById("topbar2-example").style.background = document.querySelector('input[name=color-topbar]').value
                document.getElementById("primary-color-example").style.background = document.querySelector('input[name=color-primary]').value
                document.getElementById("primary-color2-example").style.background = document.querySelector('input[name=color-primary]').value
                document.getElementById("primary-color3-example").style.background = document.querySelector('input[name=color-primary]').value
                document.getElementById("sucess-color-example").style.background = document.querySelector('input[name=color-success]').value
                document.getElementById("danger-color-example").style.background = document.querySelector('input[name=color-danger]').value
                document.getElementById("secondary-color-example").style.background = document.querySelector('input[name=color-secondary]').value
                document.getElementById("switch-color-example").style.background = document.querySelector('input[name=color-switch]').value
                document.getElementById("body-example").style.background = document.querySelector('input[name=color-background]').value


                document.getElementById("title-example").style.fontFamily = fontFamily
                document.getElementById("title6-example").style.fontFamily = fontFamily
                document.getElementById("link-example").style.fontFamily = fontFamily
                document.getElementById("link2-example").style.fontFamily = fontFamily
                document.getElementById("link3-example").style.fontFamily = fontFamily
                document.getElementById("topbar-example").style.fontFamily = fontFamily
                document.getElementById("topbar2-example").style.fontFamily = fontFamily
                document.getElementById("primary-color-example").style.fontFamily = fontFamily
                document.getElementById("primary-color2-example").style.fontFamily = fontFamily
                document.getElementById("primary-color3-example").style.fontFamily = fontFamily
                document.getElementById("sucess-color-example").style.fontFamily = fontFamily
                document.getElementById("danger-color-example").style.fontFamily = fontFamily
                document.getElementById("secondary-color-example").style.fontFamily = fontFamily
                document.getElementById("body-example").style.fontFamily = fontFamily


                function showFormAddFont () {

                    document.getElementById("formToAddFont").style.display = 'block'
                    document.getElementById('buttonHideFormAddFont').style.display = 'inline-block'
                }

                function hideFormAddFont () {

                    document.getElementById("formToAddFont").style.display = 'none'
                    document.getElementById('buttonHideFormAddFont').style.display = 'none'
                }

                function deleteFont () {

                    var element = document.getElementById("font-style");
                    var fontStyles = <?php echo json_encode($fontStyles); ?>;
                    var option = element.options[element.selectedIndex].text;

                    fontStyles.forEach((element, index) => {
                        if (element.name == option) {
                            if (element.default == false) {
                                fontStyles.splice(index, 1);
                            }
                        }
                    });

                    document.getElementById("updatedFonts").value = JSON.stringify(fontStyles)
                    document.getElementById('updatedFontsForm').click();

                }

            </script>

            <?php
                break;
            endswitch;
            ?>
        </div>

    </div>

<?php
    }
}
