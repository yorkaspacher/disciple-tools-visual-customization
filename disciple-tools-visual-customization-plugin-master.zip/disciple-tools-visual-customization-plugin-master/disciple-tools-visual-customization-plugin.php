<?php

/**
 * Plugin Name: Disciple Tools - Visual Customization
 * Plugin URI:
 * Description: Disciple Tools - Visual Customization is intended to manage Disciple Tools Theme's styles settings like (Colors, Fonts, Icons and Images).
 * Version:  0.1.0
 * Author URI:
 * GitHub Plugin URI:
 * Requires at least:
 * Tested up to:
 *
 * @package Disciple_Tools
 * @link    https://github.com/DiscipleTools
 * @license GPL-2.0 or later
 *          https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
$dt_visual_cutomization_required_dt_theme_version = '0.28.0';

/**
 * Gets the instance of the `DT_Visual_Customization_Plugin` class.
 *
 * @since  0.1
 * @access public
 * @return object|bool
 */
function dt_visual_customization_plugin()
{
    global $dt_visual_cutomization_required_dt_theme_version;
    $wp_theme = wp_get_theme();
    $version = $wp_theme->version;

    /*
     * Check if the Disciple.Tools theme is loaded and is the latest required version
     */
    $is_theme_dt = strpos($wp_theme->get_template(), "disciple-tools-theme") !== false || $wp_theme->name === "Disciple Tools";
    if ($is_theme_dt && version_compare($version, $dt_visual_cutomization_required_dt_theme_version, "<")) {
        add_action('admin_notices', 'dt_visual_cutomization_plugin_hook_admin_notice');
        add_action('wp_ajax_dismissed_notice_handler', 'dt_hook_ajax_notice_handler');
        return false;
    }
    if (!$is_theme_dt) {
        return false;
    }
    /**
     * Load useful function from the theme
     */
    if (!defined('DT_FUNCTIONS_READY')) {
        require_once get_template_directory() . '/dt-core/global-functions.php';
    }
    /*
     * Don't load the plugin on every rest request. Only those with the 'sample' namespace
     */
    $is_rest = dt_is_rest();
    //@todo change 'sample' if you want the plugin to be set up when using rest api calls other than ones with the 'sample' namespace
    if (!$is_rest) {
        return DT_Visual_Customization_Plugin::get_instance();
    }
    // @todo remove this "else if", if not using rest-api.php
    //else if ( strpos( dt_get_url_path(), 'dt_visual_customization_plugin' ) !== false ) {
    //    return DT_Visual_Customization_Plugin::get_instance();
    //}
    // @todo remove if not using a post type
    else if (strpos(dt_get_url_path(), 'visual_customization_post_type') !== false) {
        return DT_Visual_Customization_Plugin::get_instance();
    }
}
add_action('after_setup_theme', 'dt_visual_customization_plugin');


// Add filters to hook theme 'apply_filters' methods
add_filter('dt_default_logo', array('dt_visual_customization_plugin', 'set_logo_login_uri'));
add_action('wp_enqueue_scripts', array('dt_visual_customization_plugin', 'vc_styles'));
add_action( 'login_enqueue_scripts', array('dt_visual_customization_plugin', 'vc_login_styles'));
add_action('dt_details_additional_section', array('dt_visual_customization_plugin', 'render_health_metrics'));

add_filter( "dt_core_public_endpoint_settings", array('dt_visual_customization_plugin', 'get_data_progress_circle'));

/**
 * Singleton class for setting up the plugin.
 *
 * @since  0.1
 * @access public
 */
class DT_Visual_Customization_Plugin
{

    /**
     * Declares public variables
     *
     * @since  0.1
     * @access public
     * @return object
     */
    public $token;
    public $version;
    public $dir_path = '';
    public $dir_uri = '';
    public $img_uri = '';
    public $includes_path;

    /**
     * Returns the instance.
     *
     * @since  0.1
     * @access public
     * @return object
     */
    public static function get_instance()
    {

        static $instance = null;

        if (is_null($instance)) {
            $instance = new dt_visual_customization_plugin();
            $instance->setup();
            $instance->includes();
            $instance->setup_actions();
        }
        return $instance;
    }

    /**
     * Constructor method.
     *
     * @since  0.1
     * @access private
     * @return void
     */
    private function __construct()
    {
    }

    /**
     * Loads files needed by the plugin.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    private function includes()
    {
        require_once('includes/admin/admin-menu-and-tabs.php');
    }

    /**
     * Sets up globals.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    private function setup()
    {

        // Main plugin directory path and URI.
        $this->dir_path     = trailingslashit(plugin_dir_path(__FILE__));
        $this->dir_uri      = trailingslashit(plugin_dir_url(__FILE__));

        // Plugin directory paths.
        $this->includes_path      = trailingslashit($this->dir_path . 'includes');

        // Plugin directory URIs.
        $this->img_uri      = trailingslashit($this->dir_uri . 'img');

        // Admin and settings variables
        $this->token             = 'dt_visual_customization_plugin';
        $this->version             = '0.1';



        // sample rest api class
        require_once('includes/rest-api.php');

        // sample post type class
        // require_once( 'includes/post-type.php' );

        // custom site to site links
        require_once('includes/custom-site-to-site-links.php');
    }

    /**
     * Sets up main plugin actions and filters.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    private function setup_actions()
    {

        if (is_admin()) {
            // Check for plugin updates
            if (!class_exists('Puc_v4_Factory')) {
                require(get_template_directory() . '/dt-core/libraries/plugin-update-checker/plugin-update-checker.php');
            }
            /**
             * Below is the publicly hosted .json file that carries the version information. This file can be hosted
             * anywhere as long as it is publicly accessible. You can download the version file listed below and use it as
             * a template.
             * Also, see the instructions for version updating to understand the steps involved.
             * @see https://github.com/DiscipleTools/disciple-tools-version-control/wiki/How-to-Update-the-Starter-Plugin
             */
            //            @todo enable this section with your own hosted file
            //            $hosted_json = "https://raw.githubusercontent.com/DiscipleTools/disciple-tools-version-control/master/disciple-tools-visual-customization-plugin-version-control.json";
            //            Puc_v4_Factory::buildUpdateChecker(
            //                $hosted_json,
            //                __FILE__,
            //                'disciple-tools-visual-customization-plugin'
            //            );
        }

        // Internationalize the text strings used.
        add_action('init', array($this, 'i18n'), 2);

        if (is_admin()) {
            // adds links to the plugin description area in the plugin admin list.
            add_filter('plugin_row_meta', [$this, 'plugin_description_links'], 10, 4);
        }
    }

    /**
     * Filters the array of row meta for each/specific plugin in the Plugins list table.
     * Appends additional links below each/specific plugin on the plugins page.
     *
     * @access  public
     * @param   array       $links_array            An array of the plugin's metadata
     * @param   string      $plugin_file_name       Path to the plugin file
     * @param   array       $plugin_data            An array of plugin data
     * @param   string      $status                 Status of the plugin
     * @return  array       $links_array
     */
    public function plugin_description_links($links_array, $plugin_file_name, $plugin_data, $status)
    {
        if (strpos($plugin_file_name, basename(__FILE__))) {
            // You can still use `array_unshift()` to add links at the beginning.

            $links_array[] = '<a href="https://disciple.tools">Disciple.Tools Community</a>'; // @todo replace with your links.

            // add other links here
        }

        return $links_array;
    }

    function set_logo_uri($logoUri)
    {
        $logoPath = empty(get_option('vc_logo')) ? $logoUri : wp_upload_dir()["baseurl"] . get_option('vc_logo');
        return $logoPath;
    }

    function set_logo_login_uri($logoUri)
    {
        $logoLoginPath = empty(get_option('vc_logo_login')) ? $logoLoginUri : wp_upload_dir()["baseurl"] . get_option('vc_logo_login');
        return $logoLoginPath;
    }

    function get_data_progress_circle ( $settings ){

        global $wpdb;

        $wpUploadDir = wp_upload_dir();
        $group_fields = Disciple_Tools_Groups_Post_Type::instance()->get_custom_fields_settings();
        $group = DT_Posts::get_post( 'groups', get_the_ID(), true, true );

        $progressCircleOptionsActive = json_decode(get_option('vc_progress_circle_options'), TRUE);
        $customStylesCss = $wpdb->get_results( $wpdb->prepare("SELECT * FROM $wpdb->options WHERE  option_name like 'vc_%' and option_name not like '%_progress_circle_template' and option_name not like '%_progress_circle_options' ", OBJECT ));

        $progressCircleOptionsActive["url_image_default"] = get_template_directory_uri();
        $progressCircleOptionsActive["url_image_custom"] = $wpUploadDir["baseurl"];

        if($progressCircleOptionsActive){
            foreach ($progressCircleOptionsActive["default"] as $key => $value) {

                if($value["disable"] == 1) {
                    unset($progressCircleOptionsActive["default"][$key]);
                }
            }
        }

        $settings['health_metrics'] = $progressCircleOptionsActive;
        $settings['custom_styles_css'] = $customStylesCss;

        return $settings;
    }

    function render_health_metrics($section) {

        if ($section == "health-metrics") {

            global $wpdb;

            $contacts_baptized = 0;

            $wpUploadDir = wp_upload_dir();
            $group_fields = Disciple_Tools_Groups_Post_Type::instance()->get_custom_fields_settings();

            $group = DT_Posts::get_post( 'groups', get_the_ID(), true, true );

            $results = $wpdb->get_results( $wpdb->prepare("SELECT meta_value FROM $wpdb->postmeta WHERE post_id = {$group["ID"]} AND meta_key = 'health_metrics'", OBJECT ));

            foreach ($group["members"] as $key => $value) {

                $member_baptized = $wpdb->get_results( "SELECT COUNT(*) as quantity FROM $wpdb->postmeta WHERE post_id = {$value["ID"]} AND meta_value = 'milestone_baptized'", OBJECT );

                $contacts_baptized = $contacts_baptized + $member_baptized[0]->quantity;
            }
            $total_memeber_group = count($group["members"]);

            $progressCircleOptionsActive = json_decode(get_option('vc_progress_circle_options'), TRUE);

            if($progressCircleOptionsActive){
                foreach ($progressCircleOptionsActive["default"] as $key => $value) {
                    if($value["disable"] == 1 || $key == "church_commitment") {
                        unset($progressCircleOptionsActive["default"][$key]);
                    }
                }
            }

            $group_fields['health_metrics'] = $progressCircleOptionsActive;

            if (get_option('vc_progress_circle_template') != null) {
                $progressCircleTemplates = json_decode(get_option('vc_progress_circle_template'), TRUE);
            }

            ?>

            <style>

                .modal2 {
                    display: none; /* Hidden by default */
                    position: fixed; /* Stay in place */
                    z-index: 1; /* Sit on top */
                    padding-top: 16%; /* Location of the box */
                    left: 0;
                    top: 0;
                    width: 100%; /* Full width */
                    height: 100%; /* Full height */
                    overflow: auto; /* Enable scroll if needed */
                    background-color: rgb(0,0,0); /* Fallback color */
                    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
                }

                /* Modal Content */
                .modal-content2 {
                    background-color: #fefefe;
                    margin: auto;
                    padding: 20px;
                    border: 1px solid #888;
                    width: 20%;
                }

                /* The Close Button */
                .close2 {
                    color: #aaaaaa;
                    float: right;
                    font-size: 28px;
                    font-weight: bold;
                }

                .close2:hover, .close2:focus {
                    color: #000;
                    text-decoration: none;
                    cursor: pointer;
                }


                .unique-button-disabled {
                    opacity: 0.4 !important;
                }

                .unique-button-enable {
                    opacity: 1 !important;
                }

            </style>

            <section id="health-metrics_2" class="xlarge-12 large-12 medium-12 cell grid-item" style="position: absolute; left: 0%; top: 633.5px;">
                <div class="bordered-box js-progress-bordered-box collapsed" id="health-tile">

                    <h3 class="section-header"><?php echo esc_html( $group_fields["health_metrics"]["name"] )?>
                        <button class="help-button" data-section="health-metrics-help-text">
                            <img class="help-icon" src="<?php echo esc_html( get_template_directory_uri() . '/dt-assets/images/help.svg' ) ?>"/>
                        </button>
                        <button class="section-chevron chevron_down">
                            <img src="<?php echo esc_html( get_template_directory_uri() . '/dt-assets/images/chevron_down.svg' ) ?>"/>
                        </button>
                        <button class="section-chevron chevron_up" id="health-metrics_2_arrow">
                            <img src="<?php echo esc_html( get_template_directory_uri() . '/dt-assets/images/chevron_up.svg' ) ?>"/>
                        </button>
                    </h3>
                    <div class="section-body"><!-- start collapse -->

                    <div style="text-align: center;">

                        <div style="display: inline-block; border-radius: 100%; border: solid 2px #8c8a8a; width: 100px; top: 100px; left: 50px; position: absolute;">
                            <h2 id="members_in_group" style="color: #8c8a8a; margin: 0; hei"></h2>
                            <img src="" id="imageDivisionBaptizedPath" style="width: 50px; height: 15px;" />
                            <h2 id="members_baptized" style="color: #8c8a8a; margin: 0"></h2>
                         </div>
                        <canvas id="canvas-church-metrics" style="display: inline-block;" width="450" height="450"></canvas>
                        <br>
                        <button class="button" id="church_commitment">Church Commitment</button>

                    </div>

                </div></div>
            </section>

            <script type="application/javascript">


                setTimeout(() => {

                    var healthMetrics = document.getElementById('health-metrics')
                    var healthMetricsCustom = document.getElementById('health-metrics_2')

                    var divOther = document.getElementById('other')

                    divOther.parentNode.append(healthMetricsCustom);
                    document.getElementById('health-metrics').remove()

                    var canvas = document.getElementById('canvas-church-metrics');
                    let group = <?php echo json_encode($group) ?>;
                    let groupId = group.ID
                    var progressCircleBackground = <?php echo json_encode($group_fields["health_metrics"]); ?>;
                    var progressCircleTemplates = <?php echo json_encode($progressCircleTemplates); ?>;
                    var progressCircleOptionsActive = <?php echo json_encode($group_fields["health_metrics"]["default"]); ?>;
                    var iconsActive = <?php echo json_encode($results); ?>;
                    var selected_group = <?php echo json_encode($group); ?>;
                    var contacts_baptized = <?php echo json_encode($contacts_baptized); ?>;

                    console.log(group)
                    console.log(contacts_baptized)

                    var total_memeber_group = <?php echo json_encode($total_memeber_group); ?>;

                    console.log(progressCircleBackground)

                    var imagePath2 = null

                    if(progressCircleBackground.divisionBaptizedImage.includes("dt-assets")){
                        imagePath2 = '<?php echo get_template_directory_uri(); ?>';
                    } else {
                        imagePath2 = <?php echo json_encode($wpUploadDir["baseurl"]); ?>;
                    }

                    document.getElementById("imageDivisionBaptizedPath").src = imagePath2 ? imagePath2 + progressCircleBackground.divisionBaptizedImage : ""

                    document.getElementById('members_in_group').innerHTML = document.getElementById("member_count").value - contacts_baptized;
                    document.getElementById('members_baptized').innerHTML = contacts_baptized;

                    var countCircleOptionsActive = Object.keys(progressCircleOptionsActive).length

                    document.getElementById("member_count").addEventListener("change", function() {
                        document.getElementById('members_in_group').innerHTML = document.getElementById("member_count").value - contacts_baptized;
                        document.getElementById('members_baptized').innerHTML = contacts_baptized;
                    });

                    $(document).on("click", ".delete-member", function () {

                        var clickedBtnID = $(this).attr('data-id');
                        console.log(clickedBtnID)

                        setTimeout(() => {
                            API.get_post("groups", groupId ).then(resp=>{
                                group = resp
                                document.getElementById('members_in_group').innerHTML = document.getElementById("member_count").value - contacts_baptized
                                document.getElementById('members_baptized').innerHTML = contacts_baptized;
                            })
                        }, 1000);
                    })

                    $(document).on("click", ".js-create-contact-button", function () {
                        setTimeout(() => {
                            API.get_post("groups", groupId ).then(resp=>{
                                group = resp
                                document.getElementById('members_in_group').innerHTML = document.getElementById("member_count").value - contacts_baptized
                                document.getElementById('members_baptized').innerHTML = contacts_baptized;
                            })
                        }, 1000);
                    })

                    $(document).on("click", ".typeahead__group-contacts > a", function () {
                        setTimeout(() => {
                            API.get_post("groups", groupId ).then(resp=>{
                                group = resp
                                document.getElementById('members_in_group').innerHTML = document.getElementById("member_count").value - contacts_baptized
                                document.getElementById('members_baptized').innerHTML = contacts_baptized;
                            })
                        }, 1000);
                    })

                    $(document).on("click", "#church_commitment", function () {

                        $("#church_commitment").toggleClass("unique-button-enable")
                        $("#church_commitment").toggleClass("unique-button-disable")

                        let fieldId = "church_commitment"
                        $("#"+fieldId).css('opacity', ".6");
                        let already_set = _.get(group, `health_metrics`, []).includes(fieldId)
                        let update = {values:[{value:fieldId}]}

                        if ( already_set ){
                            update.values[0].delete = true;
                        }

                        API.update_post( 'groups', groupId, {"health_metrics": update }).then(groupData => {

                            group = groupData

                            iconsActive = []

                            if(group.health_metrics){
                                group.health_metrics.forEach(metrics => {
                                    iconsActive.push({meta_value: metrics})
                                });
                            }

                            context.clearRect(0, 0, canvas.width, canvas.height);

                            var churchCommitmentActive = false

                            iconsActive.forEach((elem, key) => {
                                if(elem.meta_value == "church_commitment"){
                                    churchCommitmentActive = true
                                }
                            });

                            context.beginPath();
                            if (!churchCommitmentActive) {
                                context.setLineDash([10, 10]);
                            } else {
                                context.setLineDash([]);
                            }
                            context.arc(centerX, centerY, radius, 0, 2 * Math.PI);
                            context.strokeStyle = progressCircleBackground["border"];
                            context.lineWidth = 2;
                            context.fillStyle = progressCircleBackground["background"];
                            context.globalAlpha = 1;
                            context.fill();
                            context.stroke();

                            drawProgressCircle()

                        }).catch(err=>{
                            console.log(err)
                        })
                    })

                    /* VALID IF CANVAS EXISTS */
                    if(canvas){

                        var context = canvas.getContext('2d');
                        var centerX = canvas.width / 2;
                        var centerY = canvas.height / 2;
                        var radius = 200;
                        var canvasIcons = []

                        /* SELECT THE TAMPLATE FOR THE CIRCLE */
                        switch(countCircleOptionsActive){

                            case 5:
                                applyTemplate(progressCircleTemplates["iconTemplate5"])
                            break;
                            case 6:
                                applyTemplate(progressCircleTemplates["iconTemplate6"])
                            break;
                            case 7:
                                applyTemplate(progressCircleTemplates["iconTemplate7"])
                            break;
                            case 8:
                                applyTemplate(progressCircleTemplates["iconTemplate8"])
                            break;
                            case 9:
                                applyTemplate(progressCircleTemplates["iconTemplate9"])
                            break;
                            case 10:
                                applyTemplate(progressCircleTemplates["iconTemplate10"])
                            break;
                            case 11:
                                applyTemplate(progressCircleTemplates["iconTemplate11"])
                            break;
                            case 12:
                                applyTemplate(progressCircleTemplates["iconTemplate12"])
                            break;
                        }

                        canvas.addEventListener('mousedown', function(e) {
                            getCursorPosition(canvas, e)
                        })
                    }

                    /* APPLY THE SELECTED TEMPLATE */
                    function applyTemplate (template) {

                        var index = 0

                        for (var key in progressCircleOptionsActive) {

                            var option = progressCircleOptionsActive[key]
                            var icon = template[index]
                            var imagePath = null

                            if(option.image){
                                if(option.image.includes("dt-assets")){
                                    imagePath = '<?php echo get_template_directory_uri(); ?>';
                                } else {
                                    imagePath = <?php echo json_encode($wpUploadDir["baseurl"]); ?>;
                                    console.log(imagePath)
                                }

                            }

                            icon.id = key
                            icon.label = option.label
                            icon.imageUrl = imagePath ? imagePath + option.image : ""
                            canvasIcons.push(icon)
                            index ++
                            imagePath = null
                        }

                        index = 0
                        drawProgressCircle()
                    }

                    /* DRAW THE PROGRESS CIRCLE */
                    function drawProgressCircle () {

                        var churchCommitmentActive = false

                        iconsActive.forEach((elem, key) => {
                            if(elem.meta_value == "church_commitment"){
                                $("#church_commitment").addClass("unique-button-enable")
                                churchCommitmentActive = true
                            }
                        });

                        context.beginPath();
                        if (!churchCommitmentActive) {
                            context.setLineDash([10, 10]);
                        } else {
                            context.setLineDash([]);
                        }
                        context.arc(centerX, centerY, radius, 0, 2 * Math.PI);
                        context.strokeStyle = progressCircleBackground["border"];
                        context.lineWidth = 2;
                        context.fillStyle = progressCircleBackground["background"];
                        context.globalAlpha = 1;
                        context.fill();
                        context.stroke();

                        canvasIcons.forEach((element, key) => {
                            var icon = canvas.getContext('2d');
                            var label = canvas.getContext('2d');
                            var img = new Image;
                            var iconIsActive = findIconInArray(element.id)

                            icon.id = element.id
                            img.onload = function () {

                                var imgWidth = img.width
                                var imgHeight = img.height

                                labelArray = element.label.split(' ')
                                label.globalAlpha = iconIsActive ? 1 : element.globalAlpha
                                label.fillStyle = progressCircleBackground["label"]

                                if (labelArray[0].length > 5 && labelArray.length > 1) {

                                    var labelWidth = labelArray[0].length * 4
                                    var labelTwo = labelArray[2] ? labelArray[1] + ' ' + labelArray[2] : labelArray[1]
                                    var labelTwoWidth = labelTwo.length * 4

                                    if (labelWidth > imgWidth) {

                                        var diferent = labelWidth - imgWidth

                                        label.fillText(labelArray[0], (element.x - diferent), element.y + (imgHeight + 10));
                                    } else {

                                        var diferent = (imgWidth - labelWidth)

                                        label.fillText(labelArray[0], element.x + Math.round(diferent / 3), element.y + (imgHeight + 10));
                                    }

                                    if (labelTwoWidth > imgWidth) {

                                        var diferent = labelTwoWidth - imgWidth

                                        label.fillText(labelTwo, (element.x - diferent), (element.y + 10) + (imgHeight + 10));
                                    } else {

                                        var diferent = (imgWidth - labelTwoWidth)

                                        label.fillText(labelTwo, element.x + Math.round(diferent / 3), (element.y + 10) + (imgHeight + 10));
                                    }


                                } else {

                                    var labelWidth = element.label.length * 4

                                    if (labelWidth > imgWidth) {

                                        var diferent = labelWidth - imgWidth

                                        label.fillText(element.label, (element.x - diferent), element.y + (imgHeight + 10));
                                    } else {

                                        var diferent = (imgWidth - labelWidth)

                                        label.fillText(element.label, element.x + Math.round(diferent / 3), element.y + (imgHeight + 10));
                                    }

                                }

                                icon.globalAlpha = iconIsActive ? 1 : element.globalAlpha
                                element.globalAlpha = iconIsActive ? 1 : element.globalAlpha
                                icon.drawImage(img, element.x, element.y);
                            }
                            img.src = element.imageUrl;
                        });
                    }

                    /* VALID IF THE ICON IS IN THE ARRANGEMENT OF ACTIVE ICONS */
                    function findIconInArray (key){

                        var iconFined = false

                        iconsActive.forEach(element => {
                            if(!iconFined){
                                if(key == element.meta_value) {
                                    iconFined = true
                                }
                            }
                        });

                        return iconFined;
                    }

                    /* GET CURSOR POSITION IN PROGRESS CRICLE */
                    function getCursorPosition(canvas, event) {

                        const rect = canvas.getBoundingClientRect()
                        const xAxis = event.clientX - rect.left
                        const yAxis = event.clientY - rect.top
                        var contextIcon = null

                        canvasIcons.forEach(element => {

                            if (!contextIcon) {
                                if ((xAxis >= element.x && xAxis <= element.x + 40) && (yAxis >= element.y && yAxis <= element.y + 40)){

                                    contextIcon = element
                                    var contextIconCopy = contextIcon

                                    let fieldId = element.id
                                    $("#"+fieldId).css('opacity', ".6");
                                    let already_set = _.get(group, `health_metrics`, []).includes(fieldId)
                                    let update = {values:[{value:fieldId}]}

                                    if ( already_set ){
                                        update.values[0].delete = true;
                                    }

                                    API.update_post( 'groups', groupId, {"health_metrics": update }).then(groupData => {

                                        group = groupData

                                        iconsActive = []

                                        if(group.health_metrics){
                                            group.health_metrics.forEach(metrics => {
                                                iconsActive.push({meta_value: metrics})
                                            });
                                        }

                                        context.clearRect(0, 0, canvas.width, canvas.height);

                                        var churchCommitmentActive = false

                                        iconsActive.forEach((elem, key) => {
                                            if(elem.meta_value == "church_commitment"){
                                                churchCommitmentActive = true
                                            }
                                        });

                                        context.beginPath();
                                        if (!churchCommitmentActive) {
                                            context.setLineDash([10, 10]);
                                        } else {
                                            context.setLineDash([]);
                                        }
                                        context.arc(centerX, centerY, radius, 0, 2 * Math.PI);
                                        context.strokeStyle = progressCircleBackground["border"];
                                        context.lineWidth = 2;
                                        context.fillStyle = progressCircleBackground["background"];
                                        context.globalAlpha = 1;
                                        context.fill();
                                        context.stroke();

                                        canvasIcons.forEach((element, key) => {

                                            var icon = canvas.getContext('2d');
                                            var label = canvas.getContext('2d');
                                            var img = new Image;
                                            var iconIsActive = findIconInArray(element.id)

                                            icon.id = element.id

                                            if (icon.id == contextIconCopy.id) {
                                                if(iconIsActive && contextIconCopy.globalAlpha == 1){
                                                    iconIsActive = false

                                                } else if(!iconIsActive && contextIconCopy.globalAlpha == 0.3) {
                                                    iconIsActive = true
                                                }
                                            }

                                            img.onload = function () {

                                                var imgWidth = img.width
                                                var imgHeight = img.height

                                                labelArray = element.label.split(' ')
                                                label.globalAlpha = iconIsActive ? 1 : 0.3
                                                label.fillStyle = progressCircleBackground["label"];

                                                // VALIDATION IF LABEL HAVE SPACES

                                                if (labelArray[0].length > 5 && labelArray.length > 1) {

                                                    var labelWidth = labelArray[0].length * 4
                                                    var labelTwo = labelArray[2] ? labelArray[1] + ' ' + labelArray[2] : labelArray[1]
                                                    var labelTwoWidth = labelTwo.length * 4

                                                    // LOGIC FOR LABEL ONE

                                                    if (labelWidth > imgWidth) {

                                                        var diferent = labelWidth - imgWidth

                                                        label.fillText(labelArray[0], (element.x - diferent), element.y + (imgHeight + 10));
                                                    } else {

                                                        var diferent = (imgWidth - labelWidth)

                                                        label.fillText(labelArray[0], element.x + Math.round(diferent / 3), element.y + (imgHeight + 10));
                                                    }

                                                    // LOGIC FOR LABEL TWO

                                                    if (labelTwoWidth > imgWidth) {

                                                        var diferent = labelTwoWidth - imgWidth

                                                        label.fillText(labelTwo, (element.x - diferent), (element.y + 10) + (imgHeight + 10));
                                                    } else {

                                                        var diferent = (imgWidth - labelTwoWidth)

                                                        label.fillText(labelTwo, element.x + Math.round(diferent / 3), (element.y + 10) + (imgHeight + 10));
                                                    }


                                                } else {

                                                    // LOGIC FOR LABEL

                                                    var labelWidth = element.label.length * 4

                                                    if (labelWidth > imgWidth) {

                                                        var diferent = labelWidth - imgWidth

                                                        label.fillText(element.label, (element.x - diferent), element.y + (imgHeight + 10));
                                                    } else {

                                                        var diferent = (imgWidth - labelWidth)

                                                        label.fillText(element.label, element.x + Math.round(diferent / 3), element.y + (imgHeight + 10));
                                                    }

                                                }

                                                icon.globalAlpha = iconIsActive ? 1 : 0.3
                                                element.globalAlpha = iconIsActive ? 1 : 0.3
                                                icon.drawImage(img, element.x, element.y);
                                            }
                                            img.src = element.imageUrl;
                                        });

                                    }).catch(err=>{
                                        console.log(err)
                                    })


                                }
                            } else {
                                contextIcon = null
                            }
                        });

                    }

                }, 500);

                setTimeout(() => {
                    document.getElementById("health-metrics_2_arrow").click()
                }, 1500);

            </script>

        <?php

        }
    }


    function vc_styles() {

        wp_enqueue_style('vc-styles', get_template_directory_uri() . '/dt-assets/scss/style.scss');
        wp_add_inline_style('vc-styles', "

            " . get_option('vc_url_font_style')  ."

            body {
                font-family: " . get_option('vc_font_style') . " !important;
                background-color: ". get_option('vc_color_background'). " !important;
            }

            #top-bar-menu > div:first-of-type a > img {
                content: url(".self::set_logo_uri("").");
            }

            .top-bar,
            .top-bar ul,
            #top-bar-menu .dropdown.menu a,
            #list-filter-tabs .is-active a, #list-filter-tabs .is-active a:focus {
                background-color: ".get_option('vc_color_topbar')." !important;
                color: #ffffff !important;
            }

            .top-bar .active a {
                background-color: ".get_option('vc_color_topbar')." !important;
                filter: brightness(0.85);
            }

            .list-name-link, .accordion-title {
                color: ".get_option('vc_color_topbar')." !important;
            }

            .button, .button.disabled,
            .button.disabled:focus,
            .button.disabled:hover,
            .button[disabled],
            .button[disabled]:focus,
            .button[disabled]:hover {
                background-color: ".get_option('vc_color_primary')." !important;
            }

            .button.clear,
            .button.clear.disabled,
            .button.clear.disabled:focus,
            .button.clear.disabled:hover,
            .button.clear[disabled],
            .button.clear[disabled]:focus,
            .button.clear[disabled]:hover {
                background-color: ".get_option('vc_color_secondary')." !important;
                color: ".get_option('vc_color_link')." !important;
            }

            .dt-green, a.dt-green:hover {
                background-color: ".get_option('vc_color_success')." !important;
            }

            input.dt-switch:checked+label,
            input:checked~.switch-paddle {
                background: ".get_option('vc_color_switch')." !important;
            }

            .list-name-link,
            .dropdown.menu a,
            .filter label:hover, .list-views label:hover {
                color: ".get_option('vc_color_link')." !important;
            }
            .dropdown.menu>li.is-dropdown-submenu-parent>a:after {
                border-top-color: ".get_option('vc_color_link')." !important;
            }

            .title, .section-header {
                color: ".get_option('vc_color_titles')." !important;
            }

            .detail-notification-box {
                background-color: ".get_option('vc_color_danger')." !important;
            }

        ");
    }

    function vc_login_styles() {
        wp_enqueue_style('vc-login-styles', get_template_directory_uri() . '/dt-assets/scss/style.scss');
        wp_add_inline_style('vc-login-styles', "

            #login h1 {
                display: initial !important;
            }

            .login h1 a {
                background-image: url(".self::set_logo_login_uri("").");
            }

            body {
                font-family: " . get_option('vc_font_style') . " !important;
                background-color: ". get_option('vc_color_background'). " !important;
            }

            .list-name-link,
            .dropdown.menu a,
            .filter label:hover, .list-views label:hover {
                color: ".get_option('vc_color_link')." !important;
            }

            .button, .button.disabled,
            .button.disabled:focus,
            .button.disabled:hover,
            .button[disabled],
            .button[disabled]:focus,
            .button[disabled]:hover {
                background-color: ".get_option('vc_color_primary')." !important;
            }

            a, a:focus, a:hover {
                color: ".get_option('vc_color_link')." !important;
            }

        ");
    }

    /**
     * Method that runs only when the plugin is activated.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    public static function activation()
    {

        // Confirm 'Administrator' has 'manage_dt' privilege. This is key in 'remote' configuration when
        // Disciple Tools theme is not installed, otherwise this will already have been installed by the Disciple Tools Theme
        $role = get_role('administrator');
        if (!empty($role)) {
            $role->add_cap('manage_dt'); // gives access to dt plugin options
        }

        $fontStyles = array();

        $fontStyles[] = ["name" => "Comic Sans MS", "url" => "", "default" => true];
        $fontStyles[] = ["name" => "Calibri", "url" => "", "default" => true];
        $fontStyles[] = ["name" => "Arial", "url" => "", "default" => true];

        $circleProgressOptions = [
            "name" => __( 'Church Health', 'disciple_tools' ),
            "description" => _x( "Track the progress and health of a group/church.", 'Optional Documentation', 'disciple_tools' ),
            "type" => "multi_select",
            "divisionBaptizedImage" => "/dt-assets/images/groups/baptism.svg",
            "background" => "#929292",
            "border" => "#000000",
            "label" => "#000000",
            "default" => [
                "church_baptism" => [
                    "order" => 1,
                    "label" => __( "Baptism", 'disciple_tools' ),
                    "description" => _x( "The group is baptising.", 'Optional Documentation', 'disciple_tools' ),
                    "image" => '/dt-assets/images/groups/baptism.svg',
                    "disable" => 0
                ],
                "church_bible" => [
                    "order" => 2,
                    "label" => __( "Bible Study", 'disciple_tools' ),
                    "description" => _x( "The group is studying the bible.", 'Optional Documentation', 'disciple_tools' ),
                    "image" => '/dt-assets/images/groups/word.svg',
                    "disable" => 0
                ],
                "church_communion" => [
                    "order" => 3,
                    "label" => __( "Communion", 'disciple_tools' ),
                    "description" => _x( "The group is practicing communion.", 'Optional Documentation', 'disciple_tools' ),
                    "image" => '/dt-assets/images/groups/communion.svg',
                    "disable" => 0
                ],
                "church_fellowship" => [
                    "order" => 4,
                    "label" => __( "Fellowship", 'disciple_tools' ),
                    "description" => _x( "The group is fellowshiping.", 'Optional Documentation', 'disciple_tools' ),
                    "image" => '/dt-assets/images/groups/heart.svg',
                    "disable" => 0
                ],
                "church_giving" => [
                    "order" => 5,
                    "label" => __( "Giving", 'disciple_tools' ),
                    "description" => _x( "The group is giving.", 'Optional Documentation', 'disciple_tools' ),
                    "image" => '/dt-assets/images/groups/giving.svg',
                    "disable" => 0
                ],
                "church_prayer" => [
                    "order" => 6,
                    "label" => __( "Prayer", 'disciple_tools' ),
                    "description" => _x( "The group is praying.", 'Optional Documentation', 'disciple_tools' ),
                    "image" => '/dt-assets/images/groups/prayer.svg',
                    "disable" => 0
                ],
                "church_praise" => [
                    "order" => 7,
                    "label" => __( "Praise", 'disciple_tools' ),
                    "description" => _x( "The group is praising.", 'Optional Documentation', 'disciple_tools' ),
                    "image" => '/dt-assets/images/groups/praise.svg',
                    "disable" => 0
                ],
                "church_sharing" => [
                    "order" => 8,
                    "label" => __( "Sharing the Gospel", 'disciple_tools' ),
                    "description" => _x( "The group is sharing the gospel.", 'Optional Documentation', 'disciple_tools' ),
                    "image" => '/dt-assets/images/groups/evangelism.svg',
                    "disable" => 0
                ],
                "church_leaders" => [
                    "order" => 9,
                    "label" => __( "Leaders", 'disciple_tools' ),
                    "description" => _x( "The group has leaders.", 'Optional Documentation', 'disciple_tools' ),
                    "image" => '/dt-assets/images/groups/leadership.svg',
                    "disable" => 0
                ],
                "church_commitment" => [
                    "order" => 10,
                    "label" => __( "Church Commitment", 'disciple_tools' ),
                    "description" => _x( "The group has committed to be church.", 'Optional Documentation', 'disciple_tools' ),
                    "image" => '/dt-assets/images/groups/covenant.svg',
                    "disable" => 1
                ]
            ],
            "customizable" => "add_only"
        ];

        $progressCircleTemplate = [

            "iconTemplate12" => [
                [ "id" => "", "label" => "", "x" => 200, "y" => 50, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 80, "y" => 100, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 50, "y" => 200, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 350, "y" => 200, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 80, "y" => 300, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 200, "y" => 350, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 320, "y" => 300, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 320, "y" => 100, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 140, "y" => 140, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 260, "y" => 140, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 140, "y" => 260, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 260, "y" => 260, "globalAlpha" => 0.3, "imageUrl" => "" ],
            ],

            // 11
            "iconTemplate11" => [
                [ "id" => "", "label" => "", "x" => 200, "y" => 50, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 80, "y" => 100, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 80, "y" => 300, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 200, "y" => 350, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 320, "y" => 300, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 320, "y" => 100, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 140, "y" => 140, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 260, "y" => 140, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 140, "y" => 260, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 260, "y" => 260, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 200, "y" => 200, "globalAlpha" => 0.3, "imageUrl" => "" ],
            ],

            // 10
            "iconTemplate10" => [
                [ "id" => "", "label" => "", "x" => 200, "y" => 50, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 80, "y" => 100, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 80, "y" => 300, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 200, "y" => 350, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 320, "y" => 300, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 320, "y" => 100, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 140, "y" => 140, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 260, "y" => 140, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 140, "y" => 260, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 260, "y" => 260, "globalAlpha" => 0.3, "imageUrl" => "" ],
            ],

            // 9
            "iconTemplate9" => [
                [ "id" => "", "label" => "", "x" => 200, "y" => 50, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 200, "y" => 200, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 200, "y" => 350, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 50, "y" => 200, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 350, "y" => 200, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 80, "y" => 100, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 80, "y" => 300, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 320, "y" => 300, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 320, "y" => 100, "globalAlpha" => 0.3, "imageUrl" => "" ],
            ],

            // 8
            "iconTemplate8" => [
                [ "id" => "", "label" => "", "x" => 200, "y" => 50, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 50, "y" => 200, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 350, "y" => 200, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 200, "y" => 350, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 140, "y" => 140, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 260, "y" => 140, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 140, "y" => 260, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 260, "y" => 260, "globalAlpha" => 0.3, "imageUrl" => "" ],
            ],

            // 7
            "iconTemplate7" => [
                [ "id" => "", "label" => "", "x" => 200, "y" => 50, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 80, "y" => 100, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 80, "y" => 300, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 200, "y" => 350, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 320, "y" => 300, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 320, "y" => 100, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 200, "y" => 200, "globalAlpha" => 0.3, "imageUrl" => "" ],
            ],

            // 6
            "iconTemplate6" => [
                [ "id" => "", "label" => "", "x" => 200, "y" => 50, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 80, "y" => 100, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 80, "y" => 300, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 200, "y" => 350, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 320, "y" => 300, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 320, "y" => 100, "globalAlpha" => 0.3, "imageUrl" => "" ],
            ],

            // 5
            "iconTemplate5" => [
                [ "id" => "", "label" => "", "x" => 200, "y" => 50, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 200, "y" => 200, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 200, "y" => 350, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 50, "y" => 200, "globalAlpha" => 0.3, "imageUrl" => "" ],
                [ "id" => "", "label" => "", "x" => 350, "y" => 200, "globalAlpha" => 0.3, "imageUrl" => "" ],
            ]
        ];

        add_option('vc_color_topbar', '#3f729b');
        add_option('vc_font_style', 'Arial');
        add_option('vc_url_font_style', '');
        add_option('vc_logo', '');
        add_option('vc_logo_login', '');
        add_option('vc_color_primary', '#007bff');
        add_option('vc_color_secondary', '#6c757d');
        add_option('vc_color_success', '#28a745');
        add_option('vc_color_danger', '#dc3545');
        add_option('vc_color_warning', '#ffc107');
        add_option('vc_color_info', '#17a2b8');
        add_option('vc_color_switch', '#007bff');
        add_option('vc_color_link', '#007bff');
        add_option('vc_color_titles', '#007bff');
        add_option('vc_color_background', '#fefefe');
        add_option('vc_color_tiles', '#fefefe');
        add_option('vc_url_images', wp_upload_dir()["baseurl"]);
        add_option('vc_font_styles', json_encode($fontStyles));

        //add option to the progress circle

        add_option('vc_progress_circle_options', json_encode($circleProgressOptions));
        add_option('vc_progress_circle_template', json_encode($progressCircleTemplate));

    }

    /**
     * Method that runs only when the plugin is deactivated.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    public static function deactivation()
    {
        delete_option('dismissed-dt-visual-customization');
        delete_option('vc_color_topbar');
        delete_option('vc_font_style');
        delete_option('vc_url_font_style');
        delete_option('vc_logo');
        delete_option('vc_logo_login');
        delete_option('vc_color_primary');
        delete_option('vc_color_secondary');
        delete_option('vc_color_success');
        delete_option('vc_color_danger');
        delete_option('vc_color_warning');
        delete_option('vc_color_info');
        delete_option('vc_color_switch');
        delete_option('vc_color_link');
        delete_option('vc_color_titles');
        delete_option('vc_color_background');
        delete_option('vc_color_tiles');

        delete_option('vc_font_styles');

        remove_filter('dt_default_logo', 'set_logo_uri');

        delete_option('vc_progress_circle_options');
        delete_option('vc_progress_circle_template');

    }

    /**
     * Loads the translation files.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    public function i18n()
    {
        load_plugin_textdomain('dt_visual_customization_plugin', false, trailingslashit(dirname(plugin_basename(__FILE__))) . 'languages');
    }

    /**
     * Magic method to output a string if trying to use the object as a string.
     *
     * @since  0.1
     * @access public
     * @return string
     */
    public function __toString()
    {
        return 'dt_visual_customization_plugin';
    }

    /**
     * Magic method to keep the object from being cloned.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    public function __clone()
    {
        _doing_it_wrong(__FUNCTION__, 'Whoah, partner!', '0.1');
    }

    /**
     * Magic method to keep the object from being unserialized.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    public function __wakeup()
    {
        _doing_it_wrong(__FUNCTION__, 'Whoah, partner!', '0.1');
    }

    /**
     * Magic method to prevent a fatal error when calling a method that doesn't exist.
     *
     * @param string $method
     * @param array $args
     * @return null
     * @since  0.1
     * @access public
     */
    public function __call($method = '', $args = array())
    {
        _doing_it_wrong("dt_visual_customization_plugin::" . esc_html($method), 'Method does not exist.', '0.1');
        unset($method, $args);
        return null;
    }
}
// end main plugin class

// Register activation hook.
register_activation_hook(__FILE__, ['DT_Visual_Customization_Plugin', 'activation']);
register_deactivation_hook(__FILE__, ['DT_Visual_Customization_Plugin', 'deactivation']);

function dt_visual_cutomization_plugin_hook_admin_notice()
{
    global $dt_visual_cutomization_required_dt_theme_version;
    $wp_theme = wp_get_theme();
    $current_version = $wp_theme->version;
    $message = __("'Disciple Tools - Visual Customization' plugin requires 'Disciple Tools' theme to work. Please activate 'Disciple Tools' theme or make sure it is latest version.", "dt_visual_customization_plugin");
    if ($wp_theme->get_template() === "disciple-tools-theme") {
        $message .= sprintf(esc_html__('Current Disciple Tools version: %1$s, required version: %2$s', 'dt_visual_customization_plugin'), esc_html($current_version), esc_html($dt_visual_cutomization_required_dt_theme_version));
    }
    // Check if it's been dismissed...
    if (!get_option('dismissed-dt-visual-customization', false)) { ?>
        <div class="notice notice-error notice-dt-visual-customization is-dismissible" data-notice="dt-visual-customization">
            <p><?php echo esc_html($message); ?></p>
        </div>
        <script>
            jQuery(function($) {
                $(document).on('click', '.notice-dt-visual-customization .notice-dismiss', function() {
                    $.ajax(ajaxurl, {
                        type: 'POST',
                        data: {
                            action: 'dismissed_notice_handler',
                            type: 'dt-visual-customization',
                            security: '<?php echo esc_html(wp_create_nonce('wp_rest_dismiss')) ?>'
                        }
                    })
                });
            });
        </script>
<?php }
}


/**
 * AJAX handler to store the state of dismissible notices.
 */
if (!function_exists("dt_hook_ajax_notice_handler")) {
    function dt_hook_ajax_notice_handler()
    {
        check_ajax_referer('wp_rest_dismiss', 'security');
        if (isset($_POST["type"])) {
            $type = sanitize_text_field(wp_unslash($_POST["type"]));
            update_option('dismissed-' . $type, true);
        }
    }
}
