# Disciple Tools Visual Customization
Visual Customization is intended to manage Disciple Tools Theme's styles settings like (Colors, Fonts, Icons and Images).