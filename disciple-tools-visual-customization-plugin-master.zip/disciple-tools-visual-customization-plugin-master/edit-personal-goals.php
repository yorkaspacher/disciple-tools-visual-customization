<?php
declare(strict_types=1);

/* if ( ! current_user_can( 'create_groups' ) ) {
    wp_die( esc_html( "You do not have permission to publish groups" ), "Permission denied", 403 );
} */

get_header();

$personalGoalTemplates = get_option('vc_personal_goal_templates') ? json_decode(get_option('vc_personal_goal_templates')) : [];
$userPersonalGoals = get_user_meta(get_current_user_id(), 'vc_personal_goal', true ) ? json_decode(get_user_meta(get_current_user_id(), 'vc_personal_goal', true )) : [];

if (isset($_POST['submitGoal'])) {

    $userPersonalGoals = get_user_meta(get_current_user_id(), 'vc_personal_goal', true ) ? json_decode(get_user_meta(get_current_user_id(), 'vc_personal_goal', true )) : [];

    $fecha = new DateTime();

    $goalObject = [
        "id" => sanitize_text_field($_POST['goalId']) != "" && sanitize_text_field($_POST['goalId']) != null ? sanitize_text_field($_POST['goalId']) : $fecha->getTimestamp(),
        "goalTemplate" => sanitize_text_field($_POST['goalTemplate']),
        "kindOfGoal" => sanitize_text_field($_POST['kindOfGoal']),
        "goalDescription" => sanitize_text_field($_POST['goalDescription']),
        "goalName" => sanitize_text_field($_POST['goalName']),
        "goalDeadLine" => sanitize_text_field($_POST['goalDeadLine']),
        "goalRemindmeTime" => sanitize_text_field($_POST['goalRemindmeTime']),
        "goalOften" => sanitize_text_field($_POST['goalOften']),
        "goalRemindmeDay" => sanitize_text_field($_POST['goalRemindmeDay']),
        "goalTime" => sanitize_text_field($_POST['goalTime'])
    ];

    
    foreach ($userPersonalGoals as $key => $value) {

        if($value->id == $goalObject["id"]) {
            array_splice($userPersonalGoals,$key,1);
        }
    }
    
    array_push($userPersonalGoals, $goalObject);
    update_user_meta(get_current_user_id(), 'vc_personal_goal', json_encode($userPersonalGoals));

    echo "<script> window.location.href = window.location.href.replace('/edit', ''); </script>";
   
exit();
}

?>

<div id="content" class="template-groups-new">
    <div id="inner-content" class="grid-x grid-margin-x">
        <div class="large-2 medium-12 small-12 cell"></div>

        <div class="large-8 medium-12 small-12 cell">

            <form class="js-create-group bordered-box" action="" method="post" enctype="multipart/form-data" class="form-basic">

            <h3 class="section-header">Create Personal Goal</h3>

                <input type="hidden" name="goalId" id="goalId" >

                <table class="wp-list-table widefat striped users" style="padding: 10px 0;">
                    <tbody>
                        <tr>
                            <td style="vertical-align: inherit;">
                                <label style="display: block;">Goal Template (*)</label>
                                <select name="goalTemplate" id="goalTemplate">
                                    <option value="" disabled selected>Select Option</option>
                                    <option value="my_own">Create my own</option>
                                </select>
                            </td>
                            <td style="vertical-align: inherit;">
                                <label style="display: block;">Kind of Goal (*)</label>
                                <input type="radio" id="onetime" name="kindOfGoal" value="onetime">
                                <label for="onetime">One-Time</label><br>
                                <input type="radio" id="ongoing" name="kindOfGoal" value="ongoing">
                                <label for="ongoing">Ongoing</label>
                            </td>
                            <td style="vertical-align: inherit;">
                                <label style="display: block;">Description (*)</label>
                                <textarea name="goalDescription" id="goalDescription" cols="30" rows="4"></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: inherit;">
                                <label style="display: block;">Name (*)</label>
                                <input type="text" name="goalName" id="goalName">
                            </td>
                            <td style="vertical-align: inherit; display: none" id="colGoalDeadLine">
                                <label style="display: block;">Dead Line (*)</label>
                                <input type="date" name="goalDeadLine" id="goalDeadLine">
                            </td>
                            <td style="vertical-align: inherit; display: none" id="colGoalRemindmeTime">
                                <label style="display: block;">Remind me (*)</label>
                                <select name="goalRemindmeTime" id="goalRemindmeTime">
                                    <option value="" disabled selected>Select Option</option>
                                    <option value="1_day_before">1 day before</option>
                                    <option value="2_day_before">2 day before</option>
                                    <option value="3_day_before">3 day before</option>
                                    <option value="4_day_before">4 day before</option>
                                    <option value="5_day_before">5 day before</option>
                                    <option value="6_day_before">6 day before</option>
                                    <option value="1_week_before">1 week before</option>
                                    <option value="2_week_before">2 week before</option>
                                    <option value="3_week_before">3 week before</option>
                                    <option value="4_week_before">4 week before</option>
                                    <option value="5_week_before">5 week before</option>
                                    <option value="6_week_before">6 week before</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: inherit; display: none" id="colGoalOften">
                                <label style="display: block;">How Often (*)</label>
                                <input type="radio" id="daily" name="goalOften" value="daily">
                                <label for="daily">Daily</label><br>
                                <input type="radio" id="weekly" name="goalOften" value="weekly">
                                <label for="weekly">Weekly</label><br>
                                <input type="radio" id="biWeekly" name="goalOften" value="biWeekly">
                                <label for="biWeekly">Bi-Weekly</label><br>
                                <input type="radio" id="monthy" name="goalOften" value="monthy">
                                <label for="monthy">Monthy</label><br>
                                <input type="radio" id="quarterly" name="goalOften" value="quarterly">
                                <label for="quarterly">Quarterly</label><br>
                            </td>
                            <td style="vertical-align: inherit; display: none" id="colGoalRemindmeDay">
                                <label style="display: block;">Remind me (*)</label>
                                <select name="goalRemindmeDay" id="goalRemindmeDay">
                                    <option value="" disabled selected>Select Option</option>
                                    <option value="sunday">Sunday</option>
                                    <option value="monday">Monday</option>
                                    <option value="tuesday">Tuesday</option>
                                    <option value="wednesday">Wednesday</option>
                                    <option value="thursday">Thursday</option>
                                    <option value="friday">Friday</option>
                                    <option value="saturday">Saturday</option>
                                </select>
                            </td>
                            <td style="vertical-align: inherit; display: none" id="colGoalTime">
                                <label style="display: block;">Whats Time (*)</label>
                                <input type="time" name="goalTime" id="goalTime">
                            </td>
                        </tr>
                    </tbody>
                </table>

                <div style="text-align: center">
                    <a href="http://localhost/wordpress/personal-goals/" class="button small clear">Cancel</a>
                    <button type="submit" name="submitGoal" id="submitGoal" class="button loader js-create-group-button dt-green">Save and continue editing</button>
                </div>

            </form>

        </div>

        <div class="large-2 medium-12 small-12 cell"></div>
    </div>
</div>

<script type="application/javascript">
        
        var userPersonalGoals = <?php echo json_encode($userPersonalGoals); ?>;
    var personalGoalTemplates = <?php echo json_encode($personalGoalTemplates); ?>;
    
    var goalTemplateSelector = document.getElementById('goalTemplate')

    personalGoalTemplates.forEach(element => {
        var option = document.createElement('option');
        option.value = element.id;
        option.innerHTML = element.goalName;
        goalTemplateSelector.appendChild(option);
    });

    userPersonalGoals.forEach(element => {
        var option = document.createElement('option');
        option.value = element.id;
        option.innerHTML = element.goalName;
        goalTemplateSelector.appendChild(option);
    });
        var userPersonalGoals = <?php echo json_encode($userPersonalGoals); ?>;
        var option =  JSON.parse(localStorage.getItem('personalGoal'));

        document.getElementById("goalId").value = option.id
        document.getElementById("goalTemplate").value = option.goalTemplate
        document.getElementById("goalName").value = option.goalName
        document.getElementById("goalDescription").value = option.goalDescription
        document.getElementById(option.kindOfGoal).checked = true

        if(option.goalOften != "" && option.goalOften != null){
            document.getElementById(option.goalOften).checked = true
        }
        document.getElementById("goalDeadLine").value = option.goalDeadLine
        document.getElementById("goalRemindmeTime").value = option.goalRemindmeTime
        document.getElementById("goalRemindmeDay").value = option.goalRemindmeDay
        document.getElementById("goalTime").value = option.goalTime

        var radios = document.querySelectorAll('input[type=radio][name="kindOfGoal"]');
        radios.forEach(radio => {
            if (radio.value == 'onetime' && radio.checked) {
                document.getElementById('colGoalDeadLine').style.display = 'table-cell'
                document.getElementById('colGoalRemindmeTime').style.display = 'table-cell'
                document.getElementById('colGoalOften').style.display = 'none'
                document.getElementById('colGoalRemindmeDay').style.display = 'none'
                document.getElementById('colGoalTime').style.display = 'none'
            }
            else if (radio.value == 'ongoing' && radio.checked) {
                document.getElementById('colGoalOften').style.display = 'table-cell'
                document.getElementById('colGoalRemindmeDay').style.display = 'table-cell'
                document.getElementById('colGoalTime').style.display = 'table-cell'
                document.getElementById('colGoalDeadLine').style.display = 'none'
                document.getElementById('colGoalRemindmeTime').style.display = 'none'
            }
        });

</script>

<?php
get_footer();